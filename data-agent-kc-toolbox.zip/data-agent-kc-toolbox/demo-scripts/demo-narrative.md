# Demo: Unlocking Enterprise Intelligence with Google Cloud Knowledge Catalog

**Total runtime**: ~6 minutes. Built around the `data-agent-kc` agent — an ADK agent that lets Knowledge Catalog drive its tool routing, sending BigQuery questions to Conversational Analytics, GCS documents to the MCP Toolbox, and blending both for cross-modal answers.

**Scenario**: a mid-sized retailer running on Google Cloud. **Source data**: a copy of `bigquery-public-data.thelook_ecommerce` in the demo project (orders, products, users, inventory). **Unstructured data**: a small Cloud Storage bucket of supplier contracts, customer policies, and a customer-segmentation policy — published as both markdown (which the agent reads at runtime) and PDF (which executives screenshot).

**Setup**: see [`README.md`](README.md). All sample data is created by [`setup/`](setup/) scripts. The agent is deployed twice — one **Enriched** variant with Dataplex enabled, one **Baseline** variant without.

---

## Section 1 — The Enterprise Context Gap (0:00 – 1:00)

**Aha moment**: Why traditional catalogs leave agents flying blind.

**Visual**: Slide showing three data-source icons (BigQuery, Cloud Storage, Knowledge Catalog) feeding a single agent. Behind them, a generic retail illustration.

**Speaker**:

> "Every modern enterprise is racing to put generative AI agents in front of their data — to automate customer service, streamline supply chains, query financial metrics on demand. The reality is more painful: there's a **context gap** that's halting these projects.
>
> LLMs are brilliant, but they're flying blind in your environment. They don't know what your tables mean, what your column names actually represent, or what's buried in the policy PDFs, wikis, and user guides your analysts have memorized over the years. Without a map, your AI either stalls — or worse, confidently fabricates an answer.
>
> Google Cloud **Knowledge Catalog** closes that gap with a **two-sided superpower**. First, it's a universal context engine — automatically aggregating technical schemas, operational profiles, and business semantics from BigQuery, Cloud Storage, Spanner, and partner systems into one consistent, secure foundation for discovery and retrieval-augmented generation. Second — and this is the part that actually changes the game — it uses **Gemini to enrich that data**, reading your schemas, query logs, wikis, PDFs, and user guides to capture the tribal knowledge that normally lives only in your analysts' heads, and turning it into structured, clear, searchable metadata. Your messy databases and cryptic column names become content that both AI agents *and* human analysts can finally understand.
>
> Today we'll watch a retailer use Knowledge Catalog as that universal context engine to transform raw enterprise assets into a unified, secure, AI-ready context layer. Let's start where the friction usually begins: the raw data."

---

## Act I — The Blind Agent vs. the Enriched Agent (1:00 – 2:00)

**Aha moment**: Watch the AI get *eyes*.

**Visual**: Vertex AI Agent Engine console, two **deployed** agents open side-by-side in their console chat tabs:
- **Baseline Agent** — custom agent on Gemini Enterprise, no Knowledge Catalog access.
- **Enriched Agent** — custom agent on Gemini Enterprise, Knowledge Catalog connected.

Both are real Agent Engine deployments running in the cloud; we're chatting with them through the Agent Engine console (not a local dev playground), so what the audience sees is the production runtime.

**Speaker**:

> "We have two custom agents, both built on **Gemini Enterprise**, both pointed at the same data warehouse, same model, same project. The one on the left has **no** access to Knowledge Catalog. The one on the right does. That's the only difference. We're going to ask a standard business question to both:
>
> **'For our premium customer segment, what was the average order value in Q4 2025, and which product category drove the most spend?'**"

**Visual**: Presenter pastes the question into both deployments.

**Baseline (Dataplex off)** — output looks like one of two failure modes:

> "I'd be happy to help. Could you clarify what defines a premium customer in your data? I see tables like `orders`, `users`, and `events` but I'm not sure which signals 'premium'."

…or, more dangerously, a confident-sounding answer that quietly invents its own definition (e.g., "top 10% of users by lifetime spend"). Same data, but no governance — and no way for the reader to know the agent fabricated the segment boundary.

**Enriched (Dataplex on)** — agent visibly works through the catalog, then returns:

> "Per the Customer Segmentation Policy on file, 'Premium' is defined as `users.traffic_source = 'Email'` and `users.age >= 35` with at least one completed order in the last 12 months. Applying that filter against Q4 2025 orders: **$58.01** average order value across 305 orders. The top product category by total spend was **Outerwear & Coats** at $3,483, followed by Jeans at $2,728 and Sweaters at $2,330. Generated SQL: …"

**Speaker**:

> "Instant success — and instant *governance*. Behind the scenes the Enriched Agent ran a Knowledge Catalog search, found the **Customer Segmentation Policy document** that *defines* premium, read the SQL reference filter out of that doc, picked the right BigQuery tables, and *then* invoked the Conversational Analytics API with that precise context.
>
> The Baseline Agent had access to the exact same warehouse, the same tables, the same data. What it lacked was the *map* — and notice it produces one of two bad outcomes: it stalls and asks the user to do the data team's job, or it silently makes up a definition. Both are worse than a slow, correct, audit-ready answer.
>
> And this is where AI projects either ship or quietly get shelved. In real-world enterprise analytics, the difference between an agent with curated context and one without typically pushes accuracy from the **60s to 70s — useful in a hackathon, dangerous in production — into the 90s**. That's the threshold where business actually trusts the output and the deployment graduates from demo to decision-making.
>
> This is the difference between an AI that guesses and an AI that knows."

---

## Act II — Autonomous Curation: The Catalog Builds Itself (2:00 – 2:50)

**Aha moment**: Schema enrichment isn't a months-long stewardship project — it's an autonomous workflow that the agent then exploits at runtime, across **four** layers of enrichment.

**Visual**: Switch to the Knowledge Catalog UI, opened on `retail_demo.order_items`.

**Speaker**:

> "How did the agent get smart enough to use that policy and write correct SQL? Traditionally, data stewards spent months interviewing engineers to document schemas, drafting example queries, and mapping table relationships by hand. Knowledge Catalog completely automates that step — on **four fronts**, all powered by Gemini.
>
> The schema is here automatically — Dataplex syncs it from BigQuery in real time. But look at the columns: `sale_price`, `inventory_item_id`, `status`. No descriptions on a fresh table. A human reading this can guess; an LLM is going to hallucinate when it tries.
>
> Watch what Knowledge Catalog does when I click **Generate Descriptions**."

**Visual**: Click **Generate Descriptions**. Brief progress wheel. Human-readable text fills the description column.

**Speaker**:

> "**Enrichment #1 — column descriptions.** Under the hood, built-in Gemini models evaluated actual data shapes, value distributions, foreign-key shapes, and naming conventions, and auto-populated the documentation. `sale_price` becomes 'Final per-unit price paid by the customer, in USD, after discounts'. `inventory_item_id` becomes 'Foreign key to inventory_items.id; identifies the specific physical unit shipped'. Click Save and it's committed to the enterprise schema.
>
> Now let's open the **Insights** tab."

**Visual**: Switch to the **Insights** tab — a list of AI-generated questions with their accompanying SQL queries.

**Speaker**:

> "**Enrichment #2 — Insights.** Gemini drafts the questions analysts naturally ask about this table — 'What were the top-selling products in Q4?', 'How many returns per category last month?' — and writes the SQL that answers each one. These become pre-validated query patterns the agent can lean on instead of inventing SQL from scratch, and analysts use them as starting templates for their own work. Free, machine-generated query examples for every table in the warehouse.
>
> Next, the **Data Profile**."

**Visual**: Switch to the **Data Profile** tab. Profile bars appear — distributions, null rates, top values per column, cardinality.

**Speaker**:

> "**Enrichment #3 — Data Profiles.** Live statistical fingerprints on every column: averages, null boundaries, top values, cardinality. Data quality is completely transparent, so the agent is never querying corrupted data — and at runtime the agent uses these to sanity-check itself. If it's about to filter on a column that's 90% null, it knows to reconsider.
>
> Finally, zoom out one level to the **dataset overview**."

**Visual**: Switch to the dataset overview / relationship map showing foreign keys and semantic links across `users`, `orders`, `order_items`, `products`, `inventory_items`.

**Speaker**:

> "**Enrichment #4 — Dataset-level relationships.** Foreign keys, joins, and semantic links across every table in the dataset, captured automatically. That's what lets the agent confidently span `users` → `orders` → `order_items` → `products` for our Premium-customer question without us spoon-feeding it the schema.
>
> Four layers of enrichment — descriptions, insights, profiles, and dataset-level relationships — and zero hours of human stewardship. Our agent's verification step uses all of them at runtime: descriptions to confirm it has the right table, insights as ready-made SQL exemplars, profiles to avoid corrupted columns, and the relationship map to plan its joins. The catalog isn't just documentation — it's the *runtime* the agent depends on."

---

## Act III — Unlocking Dark Data with Semantic Inference (2:50 – 3:50)

**Aha moment**: Turning a folder of PDFs into a living context.

**Visual**: Switch to the Cloud Storage bucket `retail-policies-<PROJECT>`. Show the files (both `.md` originals and `.pdf` renderings):

- `customer-segment-policy.pdf` (the segment definition Act I cited)
- `return-policy-2024.pdf`
- `supplier-jackets-carhartt-contract.pdf`
- `holiday-pricing-policy-q4.pdf`
- `vendor-sla-template.pdf`

**Speaker**:

> "Structured tables are only a fraction of the picture. Up to 80% of corporate knowledge lives in **dark data** — unstructured documents like the vendor contracts, customer policies, and supplier SLAs in this bucket.
>
> If a customer asks our support agent 'When can I get a replacement for a damaged jacket?', the answer is split across BigQuery transaction data *and* the return-policy document in this bucket. Without a catalog, the agent doesn't know either exists.
>
> Instead of building massive parsing pipelines, we point Knowledge Catalog at this bucket and toggle one game-changing feature: **Semantic Inference**."

**Visual**: Switch to the catalog's Insights view for the bucket. The documents appear as first-class catalog entries with AI-generated summaries, display names, and the `gs://...` resource URI on each.

**Speaker**:

> "Gemini read those documents directly from the raw content, summarized each one, and inferred real-world relationships — mapping product categories to the policies that govern them, suppliers to the contracts that bind them. Setup pre-created these entries via the Dataplex Catalog API, but the same outcome can be produced by running Knowledge Catalog's Context Discovery scan with Semantic Inference enabled.
>
> An unsearchable folder of text just became a living network of corporate truths an analyst — or an autonomous agent — can navigate."

**Visual**: Back to the enriched agent. Ask: **'What's our published return window for outerwear?'**

**Agent's reasoning shows**:
- Calls `dataplex_search` → finds `return-policy-2024` tagged `Category: KNOWLEDGE`
- Calls `verify_entries_for_question` → confirms relevance
- Routes to the GCS reader because the entry is a Cloud Storage object
- Returns the answer with the exact policy clause cited

**Output**:

> "Per `return-policy-2024`, outerwear has a **45-day return window** starting from the delivery date, extended to **60 days** for purchases made between Nov 1 and Dec 24 (holiday extension)."

**Speaker**:

> "The agent didn't have a special 'read policy' tool wired in by hand. It searched the catalog, the catalog said 'this is a Cloud Storage entry,' and the agent dispatched to its GCS tools automatically. Drop a new document the catalog discovers into the bucket — it becomes callable context immediately, no agent redeploy."

---

## Act IV — Cross-Modal Synthesis: The Quarterly Vendor Audit (3:50 – 5:00)

**Aha moment**: One question, two systems, multiple documents, one synthesized, audit-ready answer.

**Visual**: Back to the enriched deployment's chat tab.

**Speaker**:

> "Up until now we've looked at structured and unstructured data separately. True enterprise intelligence requires blending both. Here's the kind of question a Procurement lead actually asks — and one that's genuinely painful to answer without an agent like this:
>
> **'Run a quarterly vendor health check on Carhartt outerwear. Cover realized margin against our contract target, and customer return rate against our published policy threshold. Flag anything outside policy.'**"

**Visual**: Agent's reasoning chain streams (high-level — the audience doesn't need to read every line):

```
1. dataplex_search("Carhartt outerwear margin return rate quarterly")
   → 5 entries:
       Category: BIGQUERY  -> retail_demo.order_items
       Category: BIGQUERY  -> retail_demo.products
       Category: BIGQUERY  -> retail_demo.orders
       Category: KNOWLEDGE -> supplier-jackets-carhartt-contract
       Category: KNOWLEDGE -> return-policy-2024

2. verify_entries_for_question(...) -> YES; instruction: "Compute realized markup
   for Carhartt Outerwear & Coats; compute return rate; cross-reference each
   metric against the threshold in its governing document."

3. Route by Category:
   - BIGQUERY entries  -> call_bigquery_ca(question, entry_names)
   - KNOWLEDGE entries -> gcs_read_object on each

4. Combine results into final answer.
```

**Visual**: The agent's final output (formatted nicely):

> **Carhartt Outerwear program health — Q1 2026**
>
> | Metric | Realized (Q1 2026) | Policy/contract target | Status |
> |---|---|---|---|
> | Realized markup (`sale_price / cost`) | **2.24×** | 1.85× – 1.95× (Section 2, Carhartt contract) | ✅ Healthy — above target band |
> | Customer return rate (since 2025) | **9.5%** | Alert threshold 8% (Section 4, return-policy-2024) | ⚠️ Above threshold |
> | Volume (line items, Q1 2026) | 65 | 1,500 / yr commitment (Section 1, contract) | On pace (~260 annualized × seasonal mix) |
>
> **Margin**: realized 2.24× sits comfortably above the 1.85×–1.95× target band specified in Section 2 of the Carhartt supplier agreement. A modest year-over-year compression is visible (2.35× in 2024 → 2.24× in 2026 — about a 5% drift) but the band is still being met. No margin escalation needed.
>
> **Return rate**: Carhartt's 9.5% sits **above** the 8% alert threshold defined in Section 4 of the return policy. Per Section 3.2 of the Carhartt contract, "brands consistently above this threshold for two consecutive months trigger a joint vendor business review focused on product quality, sizing accuracy, and listing description accuracy."
>
> **Recommendation**: schedule the joint vendor business review with Carhartt's account manager (jorge.menendez@carhartt.example, per the contract header). Same flag fires for Outerwear & Coats overall (10.3% return rate), so the conversation should likely span more brands than Carhartt alone.

**Speaker**:

> "Look at what just happened. The agent ran a Knowledge Catalog search, got entries spanning two completely different systems — BigQuery for transactional data and Cloud Storage for the policy and contract — and routed each to the right tool. Conversational Analytics computed the realized markup and return rate from millions of rows. The Cloud Storage reader pulled the exact clauses that define what 'healthy' means.
>
> Notice three things. First, the agent didn't just say 'returns are 9.5%' — it said *9.5% **versus the 8% threshold defined in Section 4 of the named policy document***. Numbers without context are noise; numbers with their governing document attached are an audit. Second, the agent surfaced both the action *and* the right person to call, both pulled from the documents. Third, when one of those documents changes next quarter, the agent automatically uses the new threshold — no redeployment, no engineering ticket.
>
> No human wrote a 'check Carhartt against contract' tool. No engineer hardcoded which documents to consult. The catalog described what exists, the agent did the rest. This is cross-modal synthesis — only possible because Knowledge Catalog provides a single, unified source of context truth for both structured rows and unstructured text."

---

## Conclusion — The Always-On Universal Context Engine (5:00 – 5:30)

**Visual**: Macro dashboard showing the agent runtime, the Knowledge Catalog, and the BQ + GCS sources connected.

**Speaker**:

> "Three pillars made this work:
>
> 1. **Aggregation** — Knowledge Catalog pulled structured schemas from BigQuery, scanned unstructured documents in Cloud Storage, and unified business definitions into one searchable index.
> 2. **Enrichment** — Gemini auto-generated four layers of context over structured data — column descriptions, insights with ready-made SQL, data profiles, and dataset-level relationships — and semantic inference over unstructured documents, all with zero manual stewardship.
> 3. **Search** — A single agent used that index at runtime to find what's relevant, decide which downstream tool to call per result, and combine answers across systems.
>
> Stop letting your AI guess what your data means. Build a trusted, intelligent context foundation with Google Cloud Knowledge Catalog.
>
> Thank you."

---

## Appendix — What the demo actually proves about the agent

For the engineering audience watching: the impressive behaviour above is built from these capabilities (all in [`app/`](../app/)):

| Capability | Code |
|---|---|
| Catalog-driven tool routing per-entry System | [`app/ca_toolbox_kc_wrapper.py`](../app/ca_toolbox_kc_wrapper.py) (orchestration prompt) |
| System-partitioned Dataplex search w/ unscoped catch-all for cross-project glossaries | [`app/dataplex_utils.py:dataplex_search`](../app/dataplex_utils.py) |
| Two-variant deployments (`baseline` vs `enriched`) coexisting in one project | `VARIANT=baseline DATAPLEX_ENABLED=false` vs `VARIANT=enriched DATAPLEX_ENABLED=true` via [`Makefile`](../Makefile) |
| BigQuery → Conversational Analytics handler | [`app/ca_toolbox_agent.py:call_bigquery_ca`](../app/ca_toolbox_agent.py) |
| GCS → MCP Toolbox tools | [`app/mcp_toolbox/sources/gcs.yaml`](../app/mcp_toolbox/sources/gcs.yaml) |
| Markdown → PDF generation for the bucket | [`demo-scripts/setup/40-create-pdfs.sh`](setup/40-create-pdfs.sh) |
| End-user delegation hooks (inert today, wireable when ADK exposes user identity) | [`app/auth_utils.py`](../app/auth_utils.py) |
