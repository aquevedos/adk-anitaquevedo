#!/usr/bin/env bash
# Optional: register the policies bucket as a Dataplex asset so the markdown
# files become first-class catalog entries (i.e. discoverable via
# `dataplex_search`).
#
# The semantic-inference / auto-summary toggle from the demo narrative (Act III)
# is a UI feature — this script just sets up the underlying Dataplex Lake/Zone/
# Asset hierarchy so the GCS objects show up in the catalog. The agent will
# work either way (the unscoped KNOWLEDGE catch-all in dataplex_search picks
# them up directly from the bucket regardless of Dataplex Lake registration),
# but having proper catalog entries makes Act III's UI walkthrough land
# cleaner.
#
# Skip this script if you're tight on demo prep time — the agent demo still
# works using just the BQ catalog and direct GCS reads.

set -euo pipefail

: "${GOOGLE_CLOUD_PROJECT:?Set GOOGLE_CLOUD_PROJECT}"
: "${DEMO_BUCKET:=retail-policies-${GOOGLE_CLOUD_PROJECT}}"
: "${DATAPLEX_LOCATION:=us-central1}"
: "${DATAPLEX_LAKE:=retail-lake}"
: "${DATAPLEX_ZONE:=policies-zone}"
: "${DATAPLEX_ASSET:=policies-bucket}"

LAKE_PATH="projects/${GOOGLE_CLOUD_PROJECT}/locations/${DATAPLEX_LOCATION}/lakes/${DATAPLEX_LAKE}"
ZONE_PATH="${LAKE_PATH}/zones/${DATAPLEX_ZONE}"

# Region preflight: the bucket must be in the same single region as the
# Dataplex zone (Dataplex SINGLE_REGION zones reject US / multi-region buckets).
# Prefer `gcloud storage` (clean value output); fall back to gsutil with trim.
if gcloud storage buckets describe --help >/dev/null 2>&1; then
  BUCKET_LOCATION=$(gcloud storage buckets describe "gs://${DEMO_BUCKET}" \
                      --project="$GOOGLE_CLOUD_PROJECT" \
                      --format="value(location)" 2>/dev/null \
                    | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')
else
  BUCKET_LOCATION=$(gsutil ls -L -b "gs://${DEMO_BUCKET}" 2>/dev/null \
                    | awk -F':' '/Location constraint:/ {print $2}' \
                    | tr -d '[:space:]' \
                    | tr '[:upper:]' '[:lower:]')
fi
if [[ -n "$BUCKET_LOCATION" && "$BUCKET_LOCATION" != "$DATAPLEX_LOCATION" ]]; then
  cat >&2 <<EOF
❌ Region mismatch: bucket gs://${DEMO_BUCKET} is in '${BUCKET_LOCATION}' but
   Dataplex zone is being created in '${DATAPLEX_LOCATION}'.

   Dataplex SINGLE_REGION zones reject multi-region or differently-regioned
   buckets. To fix, recreate the bucket in the matching region:

     gsutil -m rm -r gs://${DEMO_BUCKET}
     export GCS_LOCATION=${DATAPLEX_LOCATION}
     ./setup/20-create-gcs-bucket.sh
     ./setup/30-dataplex-discovery.sh    # re-run this script
EOF
  exit 1
fi

echo "🗂  Registering gs://${DEMO_BUCKET}/ as Dataplex asset..."

# Lake
if ! gcloud dataplex lakes describe "$DATAPLEX_LAKE" \
      --location="$DATAPLEX_LOCATION" \
      --project="$GOOGLE_CLOUD_PROJECT" >/dev/null 2>&1; then
  echo "  🔧 Creating Lake $DATAPLEX_LAKE"
  gcloud dataplex lakes create "$DATAPLEX_LAKE" \
    --location="$DATAPLEX_LOCATION" \
    --project="$GOOGLE_CLOUD_PROJECT" \
    --display-name="retail" \
    --description="Demo lake for retail policy documents"
else
  echo "  ✅ Lake $DATAPLEX_LAKE exists"
fi

# Zone (raw type for unstructured)
if ! gcloud dataplex zones describe "$DATAPLEX_ZONE" \
      --lake="$DATAPLEX_LAKE" \
      --location="$DATAPLEX_LOCATION" \
      --project="$GOOGLE_CLOUD_PROJECT" >/dev/null 2>&1; then
  echo "  🔧 Creating Zone $DATAPLEX_ZONE (raw)"
  gcloud dataplex zones create "$DATAPLEX_ZONE" \
    --lake="$DATAPLEX_LAKE" \
    --location="$DATAPLEX_LOCATION" \
    --project="$GOOGLE_CLOUD_PROJECT" \
    --type=RAW \
    --resource-location-type=SINGLE_REGION \
    --display-name="Policies" \
    --description="retail unstructured policy and contract documents"
else
  echo "  ✅ Zone $DATAPLEX_ZONE exists"
fi

# Asset
if ! gcloud dataplex assets describe "$DATAPLEX_ASSET" \
      --zone="$DATAPLEX_ZONE" \
      --lake="$DATAPLEX_LAKE" \
      --location="$DATAPLEX_LOCATION" \
      --project="$GOOGLE_CLOUD_PROJECT" >/dev/null 2>&1; then
  echo "  🔧 Creating Asset $DATAPLEX_ASSET → gs://${DEMO_BUCKET}"
  gcloud dataplex assets create "$DATAPLEX_ASSET" \
    --zone="$DATAPLEX_ZONE" \
    --lake="$DATAPLEX_LAKE" \
    --location="$DATAPLEX_LOCATION" \
    --project="$GOOGLE_CLOUD_PROJECT" \
    --resource-type=STORAGE_BUCKET \
    --resource-name="projects/${GOOGLE_CLOUD_PROJECT}/buckets/${DEMO_BUCKET}" \
    --discovery-enabled
else
  echo "  ✅ Asset $DATAPLEX_ASSET exists"
fi

echo
echo "✅ Dataplex Lake/Zone/Asset set up."
echo
echo "Discovery jobs run automatically and the policy markdown will appear as"
echo "catalog entries within a few minutes. To inspect:"
echo "  gcloud dataplex assets describe $DATAPLEX_ASSET \\"
echo "    --zone=$DATAPLEX_ZONE --lake=$DATAPLEX_LAKE \\"
echo "    --location=$DATAPLEX_LOCATION --project=$GOOGLE_CLOUD_PROJECT"
