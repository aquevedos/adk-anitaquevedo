#!/usr/bin/env bash
# Convert sample-docs/*.md into PDFs and upload them to the same GCS bucket
# that already holds the markdown originals.
#
# Why this exists:
#   The agent reads the .md files directly (MCP gcs_read_object only handles
#   UTF-8 text up to 8 MiB), so the markdown files are functional. The PDFs
#   are for the demo's *audience-facing* presentation layer:
#     - executive screenshots that look like real corporate policy docs
#     - parity with how most enterprises actually publish governance content
#     - groundwork for testing the agent against PDF-extracted content via a
#       future ingest path (e.g. Document AI)
#
#   This script does NOT update the Dataplex catalog entries — those still
#   point at the .md files so the agent's existing read path keeps working
#   unchanged. If you later want the agent to surface the PDFs too, extend
#   35-create-catalog-entries.sh to register a per-file PDF entry alongside
#   each markdown one.
#
# Requirements:
#   - `make install` from the project root — installs the `demo` extra which
#     includes markdown + weasyprint. (See pyproject.toml `[project.optional-
#     dependencies].demo` and the Makefile install target.)
#   - uv (https://github.com/astral-sh/uv) — used to invoke the project venv.
#
#   WeasyPrint depends on a few system libraries (pango, cairo, gdk-pixbuf).
#   If conversion fails with "cannot load library 'libpango...'":
#     macOS: brew install pango
#     Linux: apt-get install libpango-1.0-0 libpangoft2-1.0-0 libcairo2
#
# Idempotent: PDFs are regenerated from the current markdown each run and
# overwrite whatever is in the bucket. Safe to re-run after editing any doc.

set -euo pipefail

: "${GOOGLE_CLOUD_PROJECT:?Set GOOGLE_CLOUD_PROJECT}"
: "${DEMO_BUCKET:=retail-policies-${GOOGLE_CLOUD_PROJECT}}"

DOCS_DIR="$(cd "$(dirname "$0")" && pwd)/sample-docs"
PDF_DIR="$(mktemp -d -t kc-demo-pdfs.XXXXXX)"
trap 'rm -rf "$PDF_DIR"' EXIT

# ---- tool checks -----------------------------------------------------------

command -v uv >/dev/null 2>&1 || {
  cat >&2 <<EOF
❌ 'uv' is required (used to manage Python deps for the markdown→PDF converter).
   Install:
     macOS:  brew install uv
     Linux:  curl -LsSf https://astral.sh/uv/install.sh | sh
EOF
  exit 1
}

# On macOS — especially Apple Silicon — WeasyPrint's cffi-based loader can't
# find libgobject/libpango/libcairo from brew (installed to /opt/homebrew/lib
# on M-series, /usr/local/lib on Intel) because dlopen() doesn't search there
# by default. Pre-seed DYLD_FALLBACK_LIBRARY_PATH so `import weasyprint`
# works without the user having to remember the workaround.
if [[ "$(uname)" == "Darwin" ]] && command -v brew >/dev/null 2>&1; then
  brew_prefix="$(brew --prefix 2>/dev/null || true)"
  if [[ -n "$brew_prefix" ]]; then
    export DYLD_FALLBACK_LIBRARY_PATH="${brew_prefix}/lib:${DYLD_FALLBACK_LIBRARY_PATH:-}"
  fi
fi

# Pick the right upload command (mirrors 20-create-gcs-bucket.sh).
if command -v gcloud >/dev/null 2>&1 && gcloud storage --help >/dev/null 2>&1; then
  CP_CMD=(gcloud storage cp)
  LS_CMD=(gcloud storage ls)
else
  CP_CMD=(gsutil -m cp)
  LS_CMD=(gsutil ls)
fi

# ---- light styling so output looks like a real policy doc ------------------
# Embedded CSS so the script has zero external file deps. WeasyPrint applies
# this on top of the markdown→HTML output.
CSS_FILE="$PDF_DIR/policy.css"
cat >"$CSS_FILE" <<'EOF'
@page {
  size: Letter;
  margin: 0.9in 0.9in 1.0in 0.9in;
  @bottom-right {
    content: counter(page) " / " counter(pages);
    font-family: -apple-system, Helvetica, Arial, sans-serif;
    font-size: 9pt;
    color: #888;
  }
}
body {
  font-family: -apple-system, Helvetica, Arial, sans-serif;
  font-size: 11pt;
  line-height: 1.45;
  color: #1d1d1f;
}
h1 { font-size: 20pt; margin-bottom: 0.3em; border-bottom: 2px solid #1a73e8; padding-bottom: 0.2em; }
h2 { font-size: 14pt; margin-top: 1.4em; color: #1a73e8; }
h3 { font-size: 12pt; margin-top: 1.2em; color: #202124; }
table {
  border-collapse: collapse;
  width: 100%;
  margin: 0.8em 0;
  font-size: 10pt;
}
th, td {
  border: 1px solid #dadce0;
  padding: 6px 10px;
  text-align: left;
  vertical-align: top;
}
th { background: #f1f3f4; }
code {
  font-family: "SF Mono", Menlo, Monaco, Consolas, monospace;
  font-size: 9.5pt;
  background: #f1f3f4;
  padding: 1px 4px;
  border-radius: 3px;
}
pre {
  background: #f8f9fa;
  border: 1px solid #e8eaed;
  border-radius: 4px;
  padding: 10px 12px;
  overflow: auto;
  font-size: 9pt;
}
pre code { background: none; padding: 0; }
hr { border: 0; border-top: 1px solid #dadce0; margin: 1.5em 0; }
EOF

# ---- convert ---------------------------------------------------------------

echo "📄 Converting markdown to PDF and uploading to gs://${DEMO_BUCKET}/"
echo "    Source:   $DOCS_DIR"
echo "    Staging:  $PDF_DIR"
echo

if ! ls "$DOCS_DIR"/*.md >/dev/null 2>&1; then
  echo "❌ No markdown files found in $DOCS_DIR" >&2
  exit 1
fi

# Run in the project venv (`uv run` activates .venv from pyproject.toml).
# The `demo` extra in pyproject.toml installs the markdown + weasyprint deps
# used below; `make install` is what wires that up.
PROJECT_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
DOCS_DIR="$DOCS_DIR" PDF_DIR="$PDF_DIR" CSS_FILE="$CSS_FILE" \
  uv run --quiet --project "$PROJECT_ROOT" --extra demo \
    python - <<'PYEOF'
import os
import pathlib

import markdown
from weasyprint import CSS, HTML

docs_dir = pathlib.Path(os.environ["DOCS_DIR"])
pdf_dir = pathlib.Path(os.environ["PDF_DIR"])
css_path = os.environ["CSS_FILE"]

mds = sorted(docs_dir.glob("*.md"))
if not mds:
    raise SystemExit(f"No markdown files found in {docs_dir}")

for md in mds:
    body = markdown.markdown(
        md.read_text(encoding="utf-8"),
        extensions=["tables", "fenced_code", "sane_lists", "smarty"],
    )
    # Pull the first H1 from the markdown as the doc title; fall back to the
    # filename stem. The title surfaces in the PDF metadata and viewer chrome.
    title = md.stem
    for line in md.read_text(encoding="utf-8").splitlines():
        if line.startswith("# "):
            title = line[2:].strip()
            break

    html = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title></head>
<body>{body}</body></html>"""

    out = pdf_dir / f"{md.stem}.pdf"
    HTML(string=html, base_url=str(docs_dir)).write_pdf(
        out, stylesheets=[CSS(filename=css_path)]
    )
    print(f"  📝 {md.name} → {out.name}  ({title})")
PYEOF

# ---- upload ----------------------------------------------------------------

echo
echo "☁️  Uploading PDFs..."
"${CP_CMD[@]}" "$PDF_DIR"/*.pdf "gs://${DEMO_BUCKET}/"

echo
echo "✅ PDFs uploaded. Current .pdf objects in the bucket:"
"${LS_CMD[@]}" "gs://${DEMO_BUCKET}/" | grep -E '\.pdf$' || true

echo
echo "ℹ️  The Dataplex catalog entries still point at the .md files (unchanged)."
echo "   Edit 35-create-catalog-entries.sh and rerun if you want PDF entries too."
