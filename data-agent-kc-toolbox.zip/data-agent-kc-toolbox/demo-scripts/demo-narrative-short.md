# Demo (5-min version) — Knowledge Catalog as a Universal Context Engine

A trimmed, business-audience cut of [`demo-narrative.md`](demo-narrative.md). Same five acts, same data, no implementation jargon. Total runtime ≈ 5:00.

For setup, see [`README.md`](README.md). Two agent deployments must be live: one with Knowledge Catalog enabled (the **Enriched Agent**), one without (the **Baseline Agent**).

---

## Section 1 — The Enterprise Context Gap (0:00 – 0:30)

**Visual**: Slide showing three data-source icons (BigQuery, Cloud Storage, Knowledge Catalog) feeding a single agent.

**Speaker**:

> "Enterprises want AI agents on their data, but LLMs don't know what your tables mean or what's buried in your policy PDFs — they fly blind.
>
> Google Cloud **Knowledge Catalog** closes that gap: it unifies tables, documents, and business semantics into one searchable index, *and* uses **Gemini** to mine schemas, query logs, wikis, and PDFs for the tribal knowledge your analysts carry in their heads — making it usable by AI agents and humans alike."

---

## Act I — The Blind Agent vs. the Enriched Agent (0:30 – 1:15)

**Aha moment**: Watch the AI get *eyes*.

**Visual**: Two custom agents on **Gemini Enterprise**, side-by-side. Left labeled **Baseline** (no Knowledge Catalog access). Right labeled **Enriched** (Knowledge Catalog connected).

**Speaker**:

> "We have two custom agents, both built on Gemini Enterprise, both pointed at the same data warehouse. The one on the left has **no** access to Knowledge Catalog. The one on the right does. That's the only difference. Same question to both:
>
> **'For our premium customer segment, what was their Q4 average order value, and which product category drove most of their spend?'**"

**Visual + outputs**:

- **Baseline**: "I see hundreds of tables, but I don't know which one defines 'premium' customers." *(Or, more dangerously, a confident-sounding answer that silently invents its own definition — top-10% by spend, age > 50, whatever it picked.)*
- **Enriched**: "Per our Customer Segmentation Policy, 'Premium' is defined as `users.traffic_source = 'Email'` and `users.age >= 35` with at least one completed order in the last 12 months. Applying that filter: **$58.01** average order value across 305 orders. Top product category by spend: **Outerwear & Coats**."

**Speaker**:

> "Instant success — and instant *governance*. The Enriched Agent didn't guess. It searched the catalog, found the policy that *defines* premium, and ran the query that policy mandates. The Baseline had the same tables — but no map, no governing context.
>
> And this is where AI projects either ship or quietly get shelved. In real-world enterprise analytics, the difference between an agent with curated context and one without typically pushes accuracy from the **60s to 70s — useful in a hackathon, dangerous in production — into the 90s**. That's the threshold where business actually trusts the output and the deployment graduates from demo to decision-making."

---

## Act II — Autonomous Curation: The Catalog Builds Itself (1:15 – 2:00)

**Aha moment**: The catalog that builds itself — on four fronts.

**Visual**: Switch to the Knowledge Catalog UI, opened on `order_items`. Schema is here but the columns have no descriptions.

**Speaker**:

> "So how did the agent get smart enough to use that policy and write the right SQL? Traditionally, this is months of stewardship work — analysts writing column definitions, drafting example queries, mapping table relationships by hand. Knowledge Catalog does all four automatically."

**Visual**: Stay on `order_items`. Click **Generate Descriptions**. Human-readable text fills the description column.

**Speaker**:

> "**One — column descriptions.** Gemini reads the schema, samples the data, traces foreign keys, and writes human-readable definitions. `sale_price` becomes 'final per-unit price paid by the customer, in USD, after discounts.' `inventory_item_id` becomes 'foreign key to the specific physical unit shipped.' Multiply that across every table in the warehouse — months of work, done in minutes."

**Visual**: Switch to the **Insights** tab — list of AI-generated questions with their accompanying SQL.

**Speaker**:

> "**Two — Insights.** Gemini drafts the questions analysts naturally ask about this table, with the SQL already written. 'What were the top-selling products last quarter?' — here's the query. Pre-validated patterns the agent can lean on instead of inventing SQL from scratch."

**Visual**: Switch to the **Data Profile** tab — distributions, null rates, top values, cardinality.

**Speaker**:

> "**Three — Data Profiles.** Live statistical fingerprints on every column: distributions, null rates, top values, cardinality. The agent uses these at runtime to sanity-check itself — if it's about to filter on a column that's 90% null, it knows to reconsider."

**Visual**: Switch to the dataset overview / lineage view showing relationships across tables.

**Speaker**:

> "**Four — Dataset-level relationships.** Foreign keys, joins, and semantic links across every table in the dataset, captured automatically. That's what lets the agent confidently span `users` → `orders` → `order_items` → `products` without us spoon-feeding it the schema.
>
> Four layers of enrichment — descriptions, insights, profiles, relationships — and zero hours of human stewardship. Your data team doesn't write a single line of documentation, and the agent gets all of it at runtime."

---

## Act III — Unlocking Dark Data with Semantic Inference (2:00 – 2:45)

**Aha moment**: Turning a folder of PDFs into a living context.

**Visual**: Cloud Storage bucket view. Inside: PDF policy and contract documents — Customer Segmentation Policy, Return Policy, Carhartt Supplier Agreement, Holiday Pricing, Vendor SLA.

**Speaker**:

> "Up to 80% of corporate knowledge isn't in a table — it's in 'dark data', unstructured documents like vendor contracts, customer policies, supplier SLAs.
>
> Instead of building parsing pipelines, we point Knowledge Catalog at this bucket and toggle a single feature: **Semantic Inference**."

**Visual**: Switch to the catalog's Insights view for the bucket — each PDF appears as a first-class entry with an AI-generated summary, mapped to the categories and tables it governs.

**Speaker**:

> "Gemini reads those PDFs directly from raw content, summarizes each one, and infers the real-world relationships — mapping product categories to the policies that govern them, suppliers to the contracts that bind them. An unsearchable folder of text just became a living network of corporate truths.
>
> Watch the agent put that to work."

**Visual**: Ask the enriched agent: **"What's our return window for outerwear?"**

**Output**:

> "Per our 2024 return policy, outerwear has a **45-day return window** from delivery, extended to **60 days** for purchases made between November 1 and December 24."

**Speaker**:

> "The agent searched the catalog, found the return policy, read it, and quoted it back. Drop a new policy doc into the bucket next week — the catalog picks it up, and the agent uses it the next time it's asked. No engineering work."

---

## Act IV — Cross-Modal Synthesis: The Quarterly Vendor Audit (2:45 – 4:30)

**Aha moment**: One question, two systems, multiple documents, one synthesized answer.

**Visual**: Back to the enriched agent.

**Speaker**:

> "Up until now, we've looked at structured and unstructured questions separately. True enterprise intelligence requires blending both. Here's the kind of question that typically takes a team of analysts days — a quarterly health check on Carhartt, our biggest outerwear supplier:
>
> **'Run a quarterly vendor health check on Carhartt outerwear. Cover realized margin against our contract target, and customer return rate against our published policy threshold. Flag anything outside policy.'**"

**Visual**: The agent runs. Its step-by-step reasoning chain streams — at a high level, no need to dwell:

- Searched Knowledge Catalog → returned relevant BigQuery tables AND the Carhartt supplier contract AND the customer return policy.
- Computed live metrics from millions of transaction rows.
- Pulled threshold clauses directly from the contract and policy documents.
- Cross-referenced metrics against thresholds.

**Visual**: The final output:

> **Carhartt Outerwear — Q1 health check**
>
> | Metric | Realized | Target / Threshold | Status |
> |---|---|---|---|
> | Realized markup | **2.24×** | 1.85×–1.95× (Carhartt contract) | ✅ Above target |
> | Customer return rate | **9.5%** | 8% alert (return policy) | ⚠️ Above threshold |
>
> **Recommendation**: Schedule the joint vendor review per Section 3.2 of the contract. Same flag fires for the Outerwear & Coats category overall (10.3%) — the conversation should span more brands than Carhartt alone.

**Speaker**:

> "Look at what the agent just did. It computed live numbers from millions of rows of BigQuery transactions, *and* pulled the exact threshold clauses from two separate governing documents that define what 'healthy' means.
>
> Notice the answer doesn't just say 'returns are 9.5%'. It says **9.5% against the 8% threshold defined in our return policy**. Numbers without context are noise; numbers with their governing document attached are an audit.
>
> When that threshold changes next quarter, the agent uses the new number automatically — no redeployment, no engineering ticket. This is cross-modal synthesis, and it's only possible because Knowledge Catalog provides a single source of context truth for both structured rows and unstructured text."

---

## Close — The Always-On Universal Context Engine (4:30 – 5:00)

**Visual**: Reset to a macro slide showing the three Knowledge Catalog pillars.

**Speaker**:

> "Three pillars made this possible:
>
> 1. **Aggregation** — Knowledge Catalog unified structured tables and unstructured documents into one searchable index, resolving conflicting definitions along the way.
> 2. **Enrichment** — Gemini auto-generated column descriptions, data profiles, and semantic inference over documents, with zero manual stewardship.
> 3. **Search** — A single agent used that index at runtime to retrieve relevant context and combine answers across systems.
>
> Stop letting your AI guess what your data means. Build a trusted, intelligent context foundation with Google Cloud Knowledge Catalog.
>
> Thank you."
