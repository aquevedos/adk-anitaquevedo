# Demo setup — Knowledge Catalog

Two narrative versions of the same demo: -
[`demo-narrative.md`](demo-narrative.md) — full 6-minute version with
engineering detail and an appendix. -
[`demo-narrative-short.md`](demo-narrative-short.md) — 5-minute
business-audience cut, no implementation jargon.

Both use the same setup below.

Scripts and supporting material set up:

-   A BigQuery dataset (`retail_demo`) populated from
    `bigquery-public-data.thelook_ecommerce` — orders, order_items, products,
    users, inventory_items, distribution_centers.
-   A Cloud Storage bucket (`retail-policies-<PROJECT>`) of policy and contract
    documents (markdown) — supplier SLAs, return policy, holiday pricing, vendor
    template.
-   Two coexisting agent variants:
    -   `baseline` — `DATAPLEX_ENABLED=false`, no MCP toolbox attached. The
        straw man.
    -   `enriched` — `DATAPLEX_ENABLED=true`, MCP toolbox deployed and wired up.
        The protagonist.

## Prerequisites

-   **`gcloud`, `bq`, `gsutil`** — the Google Cloud SDK.
-   **`jq`** — used by `setup/35-create-catalog-entries.sh` to compose aspect
    JSON. Install with `brew install jq` (macOS) or `apt install jq` (Linux).
-   **Active gcloud auth** — `gcloud auth login` and `gcloud auth
    application-default login`.

Step 1 of the quickstart (`./setup/00-prereqs.sh`) checks all of the above and
enables the required GCP APIs.

Two things the scripts **don't** do (you do them by hand during the demo,
intentionally — they're the live "aha" moments):

1.  Click **Generate Descriptions** on a table in Knowledge Catalog (Act II).
2.  Run **Discovery Scan + Semantic Inference** on the bucket (Act III, optional
    theater — the agent still works because `setup/35-create-catalog-entries.sh`
    pre-creates the per-file catalog entries via the API).

## Quickstart

```bash
# 0. Set required environment.
#    GCS_LOCATION MUST be a single region (Dataplex SINGLE_REGION zones reject
#    multi-region buckets). us-central1 is the default; it also matches where
#    the MCP toolbox Cloud Run service runs.
export GOOGLE_CLOUD_PROJECT="<your-project-id>"
export DEMO_DATASET="retail_demo"
export DEMO_BUCKET="retail-policies-${GOOGLE_CLOUD_PROJECT}"
export GCS_LOCATION="us-central1"

# 1. Verify prereqs (gcloud auth, jq, APIs enabled, etc.)
./setup/00-prereqs.sh

# 2. Copy thelook_ecommerce tables into the demo dataset
./setup/10-copy-bq-tables.sh

# 3. Create the GCS bucket and upload the policy markdown
./setup/20-create-gcs-bucket.sh

# 4. (Optional) Register the bucket as a Dataplex Asset so it appears in the
#    catalog UI for the Act III walkthrough.
./setup/30-dataplex-discovery.sh

# 5. Pre-create per-file Dataplex catalog entries for the policy markdown.
#    REQUIRED: without this, the agent's dataplex_search can't find policy
#    documents — Acts III and IV depend on it.
./setup/35-create-catalog-entries.sh

# 6. (Optional) Generate PDF copies of each policy doc and upload alongside
#    the markdown originals. The agent reads .md (MCP can only handle UTF-8
#    text), but PDFs make screenshots look like real corporate documents.
#    Requires pandoc + weasyprint locally — see the script header.
./setup/40-create-pdfs.sh

# 7. Deploy the two agent variants
cd ..
make deploy-all VARIANT=enriched DATAPLEX_ENABLED=true
make deploy-all VARIANT=baseline  DATAPLEX_ENABLED=false
```

Cleanup at the end of the demo: `./teardown.sh` removes the dataset, bucket,
agent deployments, and the MCP Cloud Run services for both variants.

## What gets created

Resource             | Name                                                                                             | Purpose
-------------------- | ------------------------------------------------------------------------------------------------ | -------
BQ dataset           | `${GOOGLE_CLOUD_PROJECT}.retail_demo`                                                            | Demo tables copied from `bigquery-public-data.thelook_ecommerce`
BQ tables            | 6 tables (see [setup/10-copy-bq-tables.sh](setup/10-copy-bq-tables.sh))                          | Orders / order_items / products / users / inventory_items / distribution_centers
GCS bucket           | `retail-policies-${GOOGLE_CLOUD_PROJECT}`                                                        | Policy / contract markdown
Dataplex entry type  | `policy-document` (custom, in your project)                                                      | Defines the policy-doc entry shape
Dataplex entry group | `retail-policies`                                                                                | Contains one catalog entry per policy markdown file
Dataplex entries     | one per file in `sample-docs/`, with an overview aspect and `entry_source.resource` = `gs://...` | What `dataplex_search` returns when the agent asks about policies
Agent deployment     | `data-agent-kc-baseline` (Vertex AI Agent Engine)                                                | Straw-man variant
Agent deployment     | `data-agent-kc-enriched` (Vertex AI Agent Engine)                                                | Real variant
Cloud Run service    | `data-agent-mcp-toolbox-baseline`, `data-agent-mcp-toolbox-enriched`                             | MCP toolbox for each variant
Secret Manager       | `toolbox-tools-config-baseline`, `toolbox-tools-config-enriched`                                 | Composed tools.yaml
Metadata files       | `deployment_metadata.baseline.json`, `deployment_metadata.enriched.json`                         | Variant handoff

## Estimated cost

-   BigQuery: small one-time copy (~$0.05 storage / month for ~5 GB of demo
    data).
-   Cloud Storage: <$0.01 / month for ~50 KB of markdown.
-   Vertex AI Agent Engine: free tier covers a 6-minute demo run easily.
-   Cloud Run (MCP toolbox): scales to zero; demo invocations cost <$0.01.

Run `teardown.sh` after the demo to avoid recurring storage charges.

## Demo prompts

[`demo-prompts.md`](demo-prompts.md) lists the exact prompts to use during the
demo, the variant to target with each, and the expected behavior. Use it as a
teleprompter.

## Troubleshooting

### `409: A Cloud Storage bucket named '...' already exists`

GCS bucket names are globally unique. If you deleted the bucket earlier and
immediately try to recreate it, the name may sit in soft-delete reservation for
~7 days. Or someone else may genuinely own the name globally. Either way, the
fix is to pick a different name and re-run **all three** of the bucket-using
setup scripts so they target the new name:

```bash
export DEMO_BUCKET="retail-policies-${GOOGLE_CLOUD_PROJECT}-v2"
./setup/20-create-gcs-bucket.sh
./setup/30-dataplex-discovery.sh
./setup/35-create-catalog-entries.sh
```

The bucket-creation script will also attempt to auto-restore the bucket if your
gcloud version is new enough to expose `gcloud storage buckets restore` — but
the v2-name fallback always works.

### `Cloud Storage bucket location US is invalid, allowed regions are {US_CENTRAL1}`

Your bucket was created in the `US` multi-region but Dataplex zones reject that.
Default `GCS_LOCATION` is now `us-central1`. If you previously set it to `US`,
recreate the bucket:

```bash
gsutil -m rm -r "gs://${DEMO_BUCKET}"
gcloud dataplex assets delete policies-bucket --zone=policies-zone --lake=retail-lake \
  --location=us-central1 --project="$GOOGLE_CLOUD_PROJECT" --quiet 2>/dev/null || true
gcloud dataplex zones delete policies-zone --lake=retail-lake \
  --location=us-central1 --project="$GOOGLE_CLOUD_PROJECT" --quiet
gcloud dataplex lakes delete retail-lake \
  --location=us-central1 --project="$GOOGLE_CLOUD_PROJECT" --quiet
export GCS_LOCATION=us-central1
./setup/20-create-gcs-bucket.sh
./setup/30-dataplex-discovery.sh
./setup/35-create-catalog-entries.sh
```

`setup/30-dataplex-discovery.sh` has a preflight that catches this mismatch
before it tries to create the Dataplex asset.

### `404: The destination bucket does not exist` immediately after creating it

A consistency race in `gsutil`. The script now sleeps 8s after a fresh
bucket-create and retries the upload up to 3 times; if you're still hitting it,
just re-run the upload step manually:

```bash
gsutil -m cp ./setup/sample-docs/*.md "gs://${DEMO_BUCKET}/"
```

### `gcloud.storage.buckets: Invalid choice: 'restore'`

Your gcloud is older than the version that ships `gcloud storage buckets
restore`. Run `gcloud components update` to upgrade, or just skip the restore
and use the v2-name workaround above.

### Agent doesn't find policy documents in Act III / Act IV

Verify the catalog entries exist:

```bash
gcloud dataplex entries list --entry-group=retail-policies --location=global \
  --project="$GOOGLE_CLOUD_PROJECT"
```

If the list is empty, `setup/35-create-catalog-entries.sh` didn't run
successfully — re-run it. If it succeeded but the agent still can't find them,
check that the enriched deployment has `MCP_TOOLBOX_URL` set (the agent uses MCP
`gcs_read_object` to read the file body after the catalog tells it the URI).
