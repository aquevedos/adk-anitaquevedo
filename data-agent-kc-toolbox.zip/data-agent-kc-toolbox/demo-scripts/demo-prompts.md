# Demo prompts — teleprompter

Use this as a side-screen during the demo. Each row tells you which agent variant to target, the exact prompt to paste, and what to point at in the response.

## Act I — Baseline vs Enriched (one prompt, two deployed agents)

Both agents are deployed to **Vertex AI Agent Engine**. Open each in the Agent Engine console's chat tab (not a local dev session). Paste the prompt into BOTH, baseline first.

> **Prompt**:
> *"For our premium customer segment, what was the average order value in Q4 2024, and which product category drove the largest share of spend?"*

**What to point at**:

- **Baseline** likely fails (no catalog → BQ CA gets a vague question with no schema context) or returns a confused / overly-generic answer ("I'd need to know which table to query…").
- **Enriched** runs through `dataplex_search` → `verify_entries_for_question` → `call_bigquery_ca`. The reasoning chain in the playground shows it picked specific tables (`orders`, `order_items`, `users`, `products`). The answer cites the SQL and a concrete dollar value.

If the baseline gives a coherent answer anyway (CA can sometimes self-discover), ask a more constrained follow-up to break it:

> *"Now break that down by the specific customer cohort defined as 'premium' in our user-segmentation business glossary, not your own interpretation."*

The baseline has no access to the business glossary entry. The enriched one does (via the `KNOWLEDGE` catch-all in `dataplex_search`).

---

## Act II — Catalog UI walkthrough (no prompt; show the UI)

Switch to the **Knowledge Catalog UI** in the Cloud Console. Navigate to your demo project → `retail_demo.order_items`.

**Click these in sequence**:

1. **Schema tab** — call out that `sale_price`, `inventory_item_id`, `status` have no descriptions.
2. Click **Generate Descriptions** → wait for completion → expand to show the auto-generated text.
3. Click **Run Data Profile** → show value distributions, nulls, top values per column.
4. (Optional) Navigate to **Aspects** → show that custom aspects (like a business-glossary `customer_segment` aspect on the `users` table) are pulled into the agent's context.

This act is a UI demo, not an agent prompt — but emphasize: **everything Generate Descriptions writes becomes context the agent uses in Act IV.**

---

## Act III — GCS as catalog-discoverable context

**Target**: the **Enriched** deployment in the Agent Engine console.

> **Prompt**:
> *"What's our published return window for outerwear, including any holiday extension?"*

**What to point at**:

- Reasoning chain shows `dataplex_search` returns `return-policy-2024.md` tagged `Category: KNOWLEDGE`.
- Verification confirms it's the right document.
- The agent routes to MCP's `gcs_read_object` (since the entry is in Cloud Storage) — point out: *no special "read policy" tool was wired; it's catalog → routing → MCP.*
- Final answer cites **45 days** standard, **60 days** for purchases between Nov 1 – Dec 24.

Optional follow-up to show it scales to other documents:

> *"Do we have a Q4 cap on outerwear discounting? Quote the exact rule."*

Should return the **25% Black Friday cap** from `holiday-pricing-policy-q4.md`, again routed via MCP.

---

## Act IV — Cross-modal: the quarterly vendor health check (the big one)

**Target**: the **Enriched** deployment in the Agent Engine console.

> **Prompt**:
> *"Run a quarterly vendor health check on Carhartt outerwear. I want realized margin against our contract target, and customer return rate against our published policy threshold. Flag anything outside policy and recommend who to involve."*

**What to point at as the reasoning chain runs**:

1. `dataplex_search` returns a mixed bag of entries — point at the `Category:` column showing both `BIGQUERY` (`order_items`, `products`, `orders`) and `KNOWLEDGE` (the Carhartt supplier contract markdown, the return-policy markdown).
2. `verify_entries_for_question` confirms with an instruction that explicitly mentions both metrics + their threshold-defining documents.
3. The agent **groups by System and routes**:
   - BIGQUERY entries → `call_bigquery_ca` to compute realized markup and return rate from real data
   - KNOWLEDGE entries → `gcs_read_object` on each markdown URI to pull the exact threshold clauses
4. Final answer is a scorecard table with a Realized / Target / Status column structure, citing both the source data and the document section that defines each target. The return-rate row shows ⚠️ above threshold; the recommendation includes the contact email from the contract header.

**The expected numbers** (real data — verify ahead of time with the queries in `demo-prompts.md`'s prep section, or trust the agent's read of BQ):

- Realized markup, Carhartt Outerwear & Coats, Q1 2026: **2.24×** (above the 1.85×–1.95× target band in Section 2 of the Carhartt contract → ✅)
- Return rate, Carhartt Outerwear & Coats, since 2025-01: **9.5%** (above the 8% alert in Section 4 of `return-policy-2024.md` → ⚠️)
- Recommendation: schedule the joint vendor business review per Section 3.2 of the contract; same flag fires for the category overall (10.3%), so the conversation likely spans more brands.

**The line to deliver**: *"Notice the agent didn't just give you a number — it gave you a number against the threshold from the named document that defines it. That's the difference between an analyst and a calculator. And when that policy document is updated next quarter, the agent picks up the new threshold automatically — no redeployment."*

---

## Fallback prompts (in case something breaks live)

| If this breaks | Try this instead |
|---|---|
| BQ CA gives a vague Act I answer | Ask: *"Which `traffic_source` value in our `users` table represents our premium customer segment per the business glossary?"* — narrower, more obviously catalog-dependent |
| Agent doesn't find the GCS policy in Act III | Verify the enriched deployment's MCP toolbox is up — the catalog discovery scan must have completed for the bucket and the toolbox Cloud Run service must be healthy |
| Act IV reasoning is incomplete | Break it in two: *"What's the realized markup on Carhartt outerwear since the start of 2025, by quarter? Compare to any contractual target we have on file."* then follow up with *"And separately, what's the customer return rate for Carhartt outerwear, and is it within our published policy threshold?"* |
| Network/CA flakiness | Have a screen-recorded backup of Act IV running cleanly. The point of the demo is the *capability*, not the live network. |

---

## Cleanup at the end

```bash
cd demo-scripts && ./teardown.sh
```

Removes the BQ dataset, GCS bucket, Dataplex Lake (if you ran step 30), and both agent deployments + the enriched MCP toolbox Cloud Run service.
