# Data Agent KC

A catalog-driven data analytics agent for Google Cloud. Discovers relevant data
assets via the Dataplex Knowledge Catalog and routes per-system: BigQuery
questions go to
[Conversational Analytics](https://docs.cloud.google.com/gemini/data-agents/conversational-analytics-api/overview)
for natural-language SQL + insights, Cloud Storage browsing goes through an
[MCP Toolbox](https://googleapis.github.io/genai-toolbox/) sidecar, knowledge
entries (business terms, glossaries) become grounding context. Built on
[Google ADK](https://google.github.io/adk-docs/), deployable to Vertex AI Agent
Engine in multiple coexisting variants.

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/cloud-gtm/datacloud-ai-innovation.git
cd datacloud-ai-innovation/data-agent-kc-toolbox
```

### 2. Environment setup

Prerequisites: - **uv** — Python package manager.
[Install](https://docs.astral.sh/uv/getting-started/installation/) - **Google
Cloud SDK** — `gcloud` for auth and deployment.
[Install](https://cloud.google.com/sdk/docs/install) - **make** — build
automation. - **Docker** — only needed for [Local mode](#local-mode).

Install dependencies: `bash make install`

Authenticate with Google Cloud (used by Dataplex Catalog and BigQuery
Conversational Analytics calls): `bash gcloud auth application-default login`

Set your target project: `bash export GOOGLE_CLOUD_PROJECT="<your-project-id>"
gcloud config set project "$GOOGLE_CLOUD_PROJECT"`

## Development

Project layout:

Path                                                           | What it does
-------------------------------------------------------------- | ------------
[`app/ca_toolbox_kc_wrapper.py`](app/ca_toolbox_kc_wrapper.py) | Orchestration agent definition + routing prompt. The two-prompt switch for `DATAPLEX_ENABLED` lives here.
[`app/ca_toolbox_agent.py`](app/ca_toolbox_agent.py)           | `call_bigquery_ca` — the BigQuery handler that invokes Conversational Analytics. Per-system handler pattern.
[`app/dataplex_utils.py`](app/dataplex_utils.py)               | Dataplex Knowledge Catalog search + brief/detailed context formatting.
[`app/verification_agent.py`](app/verification_agent.py)       | Entry-relevance verification step (Gemini "can these entries answer Q?").
[`app/ca_toolbox_engine_app.py`](app/ca_toolbox_engine_app.py) | Vertex AI Agent Engine entrypoint. Loads MCP tools at startup.
[`app/auth_utils.py`](app/auth_utils.py)                       | `get_user_credentials` (delegation hook) + `get_end_user_token` (MCP end-user header) + `is_local_mcp_url`.
[`app/agent.py`](app/agent.py)                                 | Simpler stub agent used by `make playground` for quick local checks.
[`app/mcp_toolbox/`](app/mcp_toolbox/)                         | MCP Toolbox manifest + per-source YAML fragments. See its [README](app/mcp_toolbox/README.md) for the operator guide.
[`app/app_utils/deploy.py`](app/app_utils/deploy.py)           | Click CLI implementing `make deploy` and `make deploy-mcp`.
[`Makefile`](Makefile)                                         | Top-level commands — `playground`, `deploy`, `deploy-mcp`, `deploy-all`, `local-mcp`, etc.
[`USER_GUIDE.md`](USER_GUIDE.md)                               | Comprehensive user & developer guide for creating a Knowledge Catalog integrated analytics agent.

## Commands

| Command                  | Description                                     |
| ------------------------ | ----------------------------------------------- |
| `make install`           | Install dependencies using uv                   |
| `make playground`        | Launch local development environment            |
| `make lint`              | Run code quality checks                         |
| `make test`              | Run unit and integration tests                  |
| `make deploy`            | Deploy agent to Agent Engine                    |
| `make deploy-mcp`        | Deploy MCP Toolbox to Cloud Run (data access    |
:                          : layer for the agent)                            :
| `make deploy-all`        | First-time setup: `deploy-mcp` then `deploy` in |
:                          : one shot                                        :
| `make compose-mcp-local` | Compose `tools.yaml` from the manifest into     |
:                          : `/tmp/tools.yaml` (no GCP calls)                :
| `make local-mcp`         | Run the MCP Toolbox locally in Docker           |
:                          : (foreground, `http\://localhost\:5001`)         :

## Evaluation

### Local Evaluation (Batch Processing)

To evaluate the agent locally with a set of test questions, use the
`batch_process.py` script. This script runs the agent locally, mocking the
Gemini Enterprise authentication by using your local Application Default
Credentials.

1.  Run the script: `bash uv run python -m app.app_utils.batch_process`

The script will create a directory `app/app_utils/eval_logs/` and store a log
file for each question (e.g., `question_1.log`), containing the raw events and
the final response.

## Deployment

To deploy the agent to Vertex AI Agent Engine:

```bash
gcloud config set project "$GOOGLE_CLOUD_PROJECT"
make deploy
```

By default this deploys with display name `data-agent-kc` to the active gcloud
project.

**Advanced Deployment Options:** - `VARIANT`: Deploy a named coexisting version
of the agent — see
[Multiple deployment variants](#multiple-deployment-variants). - `DISPLAY_NAME`:
Explicit display-name override for Vertex AI Agent Engine. Wins over
`VARIANT`-derived name. (e.g., `make deploy DISPLAY_NAME="My Custom Agent"`) -
`DATAPLEX_ENABLED`: Toggle the Knowledge Catalog search/verify steps. Default
`true`. Set to `false` to disable (e.g. `make deploy DATAPLEX_ENABLED=false`) —
see [Agent routing logic](#agent-routing-logic) for what changes.

### Multiple deployment variants

To deploy multiple coexisting versions of the agent (e.g., one with Dataplex on,
one with Dataplex off, one with a Spanner-enabled MCP toolbox), use the
`VARIANT` Makefile var:

```bash
# Default — unchanged behavior
make deploy-all
# → Agent Engine display:  data-agent-kc
#   MCP Cloud Run service: data-agent-mcp-toolbox
#   MCP secret:            toolbox-tools-config
#   Metadata file:         deployment_metadata.json

# Variant: no-dataplex
# (DATAPLEX_ENABLED=false also auto-selects manifest-no-dataplex.yaml on
# the MCP side, adding BQ introspection tools for table discovery.)
make deploy-all VARIANT=no-dataplex DATAPLEX_ENABLED=false
# → Agent Engine display:  data-agent-kc-no-dataplex
#   MCP Cloud Run service: data-agent-mcp-toolbox-no-dataplex
#   MCP secret:            toolbox-tools-config-no-dataplex
#   Metadata file:         deployment_metadata.no-dataplex.json

# Variant: with-spanner — uses a different manifest
make deploy-all VARIANT=with-spanner \
    MANIFEST=app/mcp_toolbox/manifest-with-spanner.yaml \
    EXTRA_ENV="SPANNER_INSTANCE=foo,SPANNER_DATABASE=bar"
```

**What `VARIANT` controls** (each derived value is overridable via the explicit
Makefile var listed next to it):

| Resource       | Variant-derived value                | Explicit override  |
| -------------- | ------------------------------------ | ------------------ |
| Agent Engine   | `data-agent-kc-<variant>`            | `DISPLAY_NAME=...` |
: display name   :                                      :                    :
| MCP Cloud Run  | `data-agent-mcp-toolbox-<variant>`   | `SERVICE_NAME=...` |
: service        :                                      :                    :
| MCP Secret     | `toolbox-tools-config-<variant>`     | (`--secret-name`   |
: Manager secret :                                      : on deploy.py)      :
| Deployment     | `deployment_metadata.<variant>.json` | (`--metadata-file` |
: metadata file  :                                      : on deploy.py)      :

**Shared across variants** (intentionally — no proliferation needed): - The
toolbox service account (`toolbox-identity@<project>`) — multiple Cloud Run
services can bind the same SA. - The Vertex AI Agent Engine runtime SA (default
Google-managed).

**Important**: pass the SAME `VARIANT` to both `deploy` and `deploy-mcp` (or use
`deploy-all`) so the agent picks up its variant's MCP URL from the right
metadata file. Mixing variants across the pair means the agent silently loads no
MCP tools (the metadata file the agent reads won't have an `mcp_toolbox_url` for
that variant).

**Per-variant manifests**: drop alternate manifest files alongside
`app/mcp_toolbox/manifest.yaml` and select with `MANIFEST=`:

```
app/mcp_toolbox/
├── manifest.yaml                  # default — gcs (+ disabled bigquery, spanner)
├── manifest-no-dataplex.yaml      # gcs + bigquery introspection (use with DATAPLEX_ENABLED=false)
├── manifest-with-spanner.yaml     # spanner enabled
└── manifest-extras.yaml           # adds AlloyDB, Postgres, etc.
```

Each variant deploys independently — `make deploy-mcp VARIANT=foo MANIFEST=...`
composes from that manifest, into a variant-named secret + Cloud Run service.
Updating one variant doesn't affect the others.

**Inspecting deployed variants**: `ls deployment_metadata*.json` shows which
variants have been deployed from this checkout. `cat
deployment_metadata.<variant>.json` shows their URLs + SAs.

## Local mode

You can run the entire stack — agent playground + MCP Toolbox — on your laptop,
with no Cloud Run deploy. Useful for iterating on the manifest, the
orchestration prompt, or new MCP source fragments before paying for a real
deploy.

**Prerequisites**: Docker (for the toolbox container) and `gcloud auth
application-default login` (the toolbox reuses your ADC to call BigQuery /
Dataplex / GCS as you).

**Two-terminal workflow:**

```bash
# Terminal 1 — start the MCP Toolbox locally
make local-mcp
# (composes /tmp/tools.yaml from manifest.yaml, then runs the toolbox container
#  on http://localhost:5001 with your ADC mounted. Ctrl+C to stop.
#  Port 5001 is the default because 5000 is reserved by macOS AirPlay Receiver.)

# Terminal 2 — start the agent playground pointed at it
MCP_TOOLBOX_URL=http://localhost:5001 make playground
```

The agent auto-detects localhost URLs and skips the Cloud Run ID token (which
would fail against a non-Google audience anyway) — see `is_local_mcp_url` in
[`app/auth_utils.py`](app/auth_utils.py). All other auth — your ADC for BQ CA +
Dataplex, and the toolbox's ADC for its own data calls — works the same as in
production.

**Variants:**

-   **Just compose, run toolbox yourself** (skip Docker, use `go run` from the
    [`mcp-toolbox`](../mcp-toolbox/) checkout): `bash make compose-mcp-local #
    writes /tmp/tools.yaml cd ../mcp-toolbox && go run .
    --config=/tmp/tools.yaml --port=5001`

-   **Different port**: `make local-mcp PORT=8081` then
    `MCP_TOOLBOX_URL=http://localhost:8081 make playground`.

-   **Enable Spanner locally**: edit
    [`app/mcp_toolbox/manifest.yaml`](app/mcp_toolbox/manifest.yaml) to flip
    `spanner.enabled: true`, then `make local-mcp
    EXTRA_ENV="SPANNER_INSTANCE=foo,SPANNER_DATABASE=bar"`.

-   **Skip MCP entirely** (just agent + CA + direct-SDK Dataplex): `make
    playground` with no `MCP_TOOLBOX_URL` set. The agent logs a warning and runs
    with stub + direct-SDK tools only.

**Behavior differences vs. deployed mode:**

-   The local toolbox uses **your user ADC** end-to-end (BQ CA, Dataplex, GCS
    calls all run as you). In deployed mode, BQ CA + Dataplex run as the Agent
    Engine SA and GCS via MCP runs as `toolbox-identity`. So local mode is
    closer to "user-delegated" than deployed mode currently is — a useful
    side-effect for testing governance assumptions.
-   No Cloud Run IAM gate locally. The toolbox happily accepts any caller on
    localhost.
-   No Secret Manager involvement. The composed `tools.yaml` lives at
    `/tmp/tools.yaml` on your disk.

## Data access architecture

The agent talks to three data systems via three different paths, each chosen for
governance reasons:

System                                                         | Path                                                                     | File
-------------------------------------------------------------- | ------------------------------------------------------------------------ | ----
BigQuery (SQL execution)                                       | **BigQuery CA** (Conversational Analytics — NL→SQL→execute→insights)     | [`app/ca_toolbox_agent.py`](app/ca_toolbox_agent.py)
BigQuery (table discovery, only when `DATAPLEX_ENABLED=false`) | **MCP Toolbox** — `bigquery_list_*` / `bigquery_get_table_info`          | [`app/mcp_toolbox/sources/bigquery.yaml`](app/mcp_toolbox/sources/bigquery.yaml)
Dataplex                                                       | **Direct `dataplex_v1` SDK** with `tool_context.auth` → user-cred-or-ADC | [`app/dataplex_utils.py`](app/dataplex_utils.py)
GCS (and future sources)                                       | **MCP Toolbox** sidecar (Cloud Run, `toolbox-core`)                      | [`app/mcp_toolbox/`](app/mcp_toolbox/)

The direct paths preserve a clean delegation hook
(`get_user_credentials(tool_context)`) so end-user-bound execution lights up
automatically when ADK populates `ToolContext.auth` with the calling user's
identity. The MCP path is reserved for sources where SA-only access is
acceptable and where MCP's manifest-driven extensibility (drop a YAML, redeploy)
is worth more than its current delegation gap. BigQuery *introspection* (no
execution) is also offered via MCP, but only when the agent is deployed with
`DATAPLEX_ENABLED=false` — see
[`app/mcp_toolbox/README.md`](app/mcp_toolbox/README.md#why-this-projects-mcp-is-scoped-this-way)
for the architectural reasoning.

### Agent routing logic

The orchestration agent (defined in
[`app/ca_toolbox_kc_wrapper.py`](app/ca_toolbox_kc_wrapper.py)) is a single
`LlmAgent` that follows a **3-step workflow** driven by the Knowledge Catalog —
the catalog itself tells the agent what tools to call, rather than the agent
assuming everything is a BigQuery question.

```
User question
    │
    ▼
[1] dataplex_search ─────► returns entries tagged with `Category: BIGQUERY|DATAPLEX|KNOWLEDGE`
    │                       (3 system-filtered searches under the hood, deduped)
    ▼
[2] verify_entries_for_question ─► Gemini check: "can these entries answer this Q?"
    │   (iterate 1↔2 until verification passes)
    ▼
[3] route by `Category:` and execute ─► fan out per system, combine results
```

#### Step 3 — routing rules

The orchestration prompt instructs the LLM to **group verified entries by their
`Category:` field and route each group to the appropriate handler**:

`Category:` on the entry                                                      | Handler the agent calls                                                                                                                                                                                                          | Why
----------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---
`BIGQUERY`                                                                    | `call_bigquery_ca` ([`ca_toolbox_agent.py`](app/ca_toolbox_agent.py)) — invokes [Conversational Analytics API](https://docs.cloud.google.com/gemini/data-agents/conversational-analytics-api/overview) (NL→SQL→execute→insights) | CA does end-to-end analytical orchestration; the right primitive for analytical questions over BQ tables.
`CLOUD_STORAGE` (or GCS-shaped entry names)                                   | MCP `gcs_list_buckets` / `gcs_list_objects` / `gcs_read_object` directly                                                                                                                                                         | MCP tools are simple enough for direct LLM dispatch.
`SPANNER` (only when enabled in the MCP manifest)                             | MCP `spanner_execute_sql` / `spanner_list_tables` directly                                                                                                                                                                       | Same — direct dispatch from the prompt.
`KNOWLEDGE` / `DATAPLEX` (business terms, glossaries, semantic relationships) | **No tool call.** Fold descriptions into the final answer as grounding context.                                                                                                                                                  | These are metadata-only entries — nothing to execute.
Anything else                                                                 | Use whatever tool description fits, or report "no execution tool wired for this source"                                                                                                                                          | Graceful fallback as new MCP sources are added.

A single question can produce a **mix** (e.g., a BigQuery table + a business
term + a GCS file). The agent calls each relevant handler in parallel-ish and
combines results in the final response.

#### Why catalog-driven routing

The catalog already knows what *system* each entry belongs to. Surfacing that as
`Category:` in the search output and letting the LLM dispatch on it gives the
agent three properties:

-   **Extensible**: new MCP sources become routable just by being mentioned in
    the prompt's routing table (or being LLM-discoverable via tool
    descriptions).
-   **Mixed-source aware**: a single question that touches both a BigQuery table
    and a GCS file (and a business term for grounding) gets a single answer that
    calls each relevant handler and stitches the output.
-   **Per-system handler pattern for non-trivial orchestration**: see the
    `call_bigquery_ca` docstring in
    [`app/ca_toolbox_agent.py`](app/ca_toolbox_agent.py) for the convention
    (`call_<system>_*`). Systems whose existing MCP tools are sufficient skip
    the wrapper entirely and are called directly from the orchestration prompt.

#### Disabling Dataplex

Set the env var `DATAPLEX_ENABLED=false` to drop the catalog steps entirely.
Useful when the project has no populated Knowledge Catalog, or when you want to
test the agent against raw data without the catalog mediating.

Without Dataplex, the LLM needs another way to find BigQuery tables before
handing them to Conversational Analytics (CA requires explicit table
references). `DATAPLEX_ENABLED=false` also auto-selects
[`manifest-no-dataplex.yaml`](app/mcp_toolbox/manifest-no-dataplex.yaml) on the
MCP side, so a single command sets up both pieces:

```bash
make deploy-all VARIANT=no-kc DATAPLEX_ENABLED=false
```

With Dataplex disabled:

-   **Tools registered on the agent**: `call_bigquery_ca` only (search + verify
    are omitted). MCP tools still load as usual — now including
    `bigquery_list_datasets` / `bigquery_list_tables` /
    `bigquery_get_table_info` for discovery (no `bigquery_execute_sql` — CA
    still owns execution).
-   **Orchestration prompt** swaps to a two-step dispatch: the LLM uses the BQ
    introspection tools to find candidate tables, then passes their
    fully-qualified paths to `call_bigquery_ca`. For non-BQ systems (GCS,
    Spanner), it dispatches directly to the matching MCP tool.
-   **`call_bigquery_ca` rejects empty `entry_names`** with a steering message
    pointing the LLM back to the discovery path — keeps it from looping into
    CA's `REFERENCES_NOT_SET` error.

Trade-offs: faster + simpler (no search/verify round-trips, no Dataplex IAM
dependency) but the LLM loses the catalog-driven multi-system routing — non-BQ
entries can't be discovered via search, only via the user's question phrasing
matching a tool description.

#### Where `Category:` comes from

`dataplex_search` ([`app/dataplex_utils.py`](app/dataplex_utils.py)) runs
**three searches** under the hood and merges/dedupes the results:

Search              | Query shape                                                                     | Project scope | Why
------------------- | ------------------------------------------------------------------------------- | ------------- | ---
BigQuery            | `{q} system=BIGQUERY type=(TABLE\|VIEW) projectid:(<DATAPLEX_CATALOG_PROJECT>)` | scoped        | Surfaces queryable BQ tables/views in the team's project
Dataplex            | `{q} system=DATAPLEX projectid:(<DATAPLEX_CATALOG_PROJECT>)`                    | scoped        | Dataplex zones / assets in the team's project
Knowledge catch-all | `{q}` (no system, no project filter)                                            | **unscoped**  | Picks up glossaries, business terms, custom docs — which often live in a separate org-level / docs project. Already-tagged entries dedupe; the catch-all only adds entries the specific searches missed.

Results merge with **first-source-wins** dedup, so an entry that matches both
the BQ search and the catch-all keeps its `BIGQUERY` system tag. The catch-all
just broadens recall to cross-project context.

#### Catalog project configuration

The scoped searches use `PROJECT_NAME` for `projectid:(...)`, resolved as:

1.  `DATAPLEX_CATALOG_PROJECT` env var, if set — use this when the agent runs in
    a different project than the one hosting the catalog.
2.  Otherwise `GOOGLE_CLOUD_PROJECT` (the agent's active project).

```bash
# Agent runs in project-A, but BQ/Dataplex assets are catalogued in project-B
make deploy DATAPLEX_CATALOG_PROJECT=project-B
# (pass via --set-env-vars or extend the Makefile to forward the variable)
```

The catch-all KNOWLEDGE search has no project filter at all, so glossaries
living in `project-C` (a central docs project, say) still surface.

### MCP Toolbox

**First-time setup**: `make deploy-all` (does `deploy-mcp` then `deploy` in
order).

Under the hood: 1. `make deploy-mcp` — toolbox deploys. The agent's runtime SA
is predicted from the project number (Google's standard
`service-{N}@gcp-sa-aiplatform-re.iam.gserviceaccount.com` pattern), so the
invoker grant happens here. Writes the toolbox URL to
`deployment_metadata.json`. 2. `make deploy` — agent deploys, picks up
`MCP_TOOLBOX_URL` from the metadata file, and loads the toolbox tools at
startup.

**Steady state**: a single command for whichever side changed. `make deploy-mcp`
for a tools.yaml/manifest change; `make deploy` for an agent change. Custom-SA
edge case: if you deploy the agent with `--agent-identity` or
`--service-account`, re-run `make deploy-mcp` once after `make deploy` so it can
grant invoker on the actual SA from metadata.

See [`app/mcp_toolbox/README.md`](app/mcp_toolbox/README.md) for the full
operator guide: adding sources, access governance, troubleshooting, and
re-enabling Spanner.

## Observability

Built-in telemetry exports to Cloud Trace, BigQuery, and Cloud Logging.
