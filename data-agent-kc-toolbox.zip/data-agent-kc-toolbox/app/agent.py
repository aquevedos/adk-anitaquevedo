# ruff: noqa
# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import datetime
import logging
import os
from zoneinfo import ZoneInfo

from app.auth_utils import get_end_user_token, is_local_mcp_url
from google.adk.agents import Agent
from google.adk.apps import App
from google.adk.models import Gemini
from google.adk.tools.function_tool import FunctionTool
import google.auth
from google.genai import types

_, project_id = google.auth.default()
os.environ["GOOGLE_CLOUD_PROJECT"] = project_id
os.environ["GOOGLE_CLOUD_LOCATION"] = "global"
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"


def get_weather(query: str) -> str:
  """Simulates a web search. Use it get information on weather.

  Args:
      query: A string containing the location to get weather information for.

  Returns:
      A string with the simulated weather information for the queried location.
  """
  if "sf" in query.lower() or "san francisco" in query.lower():
    return "It's 60 degrees and foggy."
  return "It's 90 degrees and sunny."


def get_current_time(query: str) -> str:
  """Simulates getting the current time for a city.

  Args:
      city: The name of the city to get the current time for.

  Returns:
      A string with the current time information.
  """
  if "sf" in query.lower() or "san francisco" in query.lower():
    tz_identifier = "America/Los_Angeles"
  else:
    return f"Sorry, I don't have timezone information for query: {query}."

  tz = ZoneInfo(tz_identifier)
  now = datetime.datetime.now(tz)
  return (
      f"The current time for query {query} is"
      f" {now.strftime('%Y-%m-%d %H:%M:%S %Z%z')}"
  )


async def _load_mcp_tools(url: str):
  """Load MCP Toolbox tools and wrap them for ADK.

  Mirrors ca_toolbox_engine_app.
  """
  from toolbox_core import ToolboxClient, auth_methods

  async def _user_auth_header() -> str | None:
    token = get_end_user_token()
    return f"Bearer {token}" if token else None

  client_headers: dict = {"X-Goog-User-Authorization": _user_auth_header}
  if not is_local_mcp_url(url):
    client_headers["Authorization"] = auth_methods.aget_google_id_token(url)
  else:
    logging.info(
        f"MCP_TOOLBOX_URL is local ({url}); skipping Cloud Run ID token."
    )

  client = ToolboxClient(url, client_headers=client_headers)
  toolbox_tools = await client.load_toolset()
  return [FunctionTool(func=t) for t in toolbox_tools]


def _mcp_tools_or_empty() -> list:
  """Sync wrapper for local-dev tool loading. Returns [] on any failure.

  Called at module import time. If we're already inside a running event
  loop (e.g. `adk web --reload_agents` re-importing this module), skip —
  the production path uses the async lifecycle hook in ca_toolbox_engine_app.
  """
  url = os.environ.get("MCP_TOOLBOX_URL")
  if not url:
    return []
  try:
    asyncio.get_running_loop()
    logging.warning(
        "MCP_TOOLBOX_URL is set but a running event loop was detected at "
        "import time; skipping MCP tool load. Restart the playground to "
        "pick up tools."
    )
    return []
  except RuntimeError:
    pass  # no loop running — safe to use asyncio.run
  try:
    return asyncio.run(_load_mcp_tools(url))
  except Exception as e:
    logging.warning(
        f"Failed to load MCP Toolbox tools from {url}: {e}. "
        "Playground will run with stub tools only."
    )
    return []


root_agent = Agent(
    name="root_agent",
    model=Gemini(
        model="gemini-3-flash-preview",
        retry_options=types.HttpRetryOptions(attempts=3),
    ),
    instruction=(
        "You are a helpful AI assistant designed to provide accurate and useful"
        " information."
    ),
    tools=[get_weather, get_current_time, *_mcp_tools_or_empty()],
)

app = App(
    root_agent=root_agent,
    name="app",
)
