# MCP Toolbox

Operator guide for the MCP Toolbox sidecar that brokers auxiliary data access
for `data-agent-kc`.

## What this is

A separate Cloud Run service running the official
[MCP Toolbox](https://googleapis.github.io/genai-toolbox/) image. The agent
(deployed to Vertex AI Agent Engine) calls into it over HTTPS for **GCS access
and future sources** that don't have a dedicated path. **SQL execution for
BigQuery stays on the direct CA path** — MCP only provides BigQuery
*introspection* (list datasets/tables, get schemas) and only when the agent is
deployed with `DATAPLEX_ENABLED=false`. **Dataplex never goes through MCP**. See
[Why this project's MCP is scoped this way](#why-this-projects-mcp-is-scoped-this-way)
below.

Auth uses two headers; the second is reserved for future end-user delegation:

```
                Authorization: Bearer <agent-SA Google ID token>   ← Cloud Run IAM gate
                X-Goog-User-Authorization: Bearer <end-user token>  ← reserved (see governance)

End User ──► Agent (Vertex AI Agent Engine) ──► MCP Toolbox (Cloud Run) ──► GCS / Spanner / ...
```

The toolbox config (`tools.yaml`) is composed at deploy time from per-source
YAML fragments in [`sources/`](sources/), driven by
[`manifest.yaml`](manifest.yaml). Composed YAML lives in Secret Manager
(`toolbox-tools-config`) and is mounted into the container at `/app/tools.yaml`.

## Why this project's MCP is scoped this way

The agent has three primary data systems and the right access path for each is
different:

System                                          | Path used                                                      | Why
----------------------------------------------- | -------------------------------------------------------------- | ---
BigQuery (SQL execution)                        | **BigQuery CA** (`call_bigquery_ca` → geminidataanalytics API) | CA is an analytical layer that does NL→SQL→execute→insights in one call. MCP's `bigquery-execute-sql` would replace CA's value-add with a lower-level primitive. CA also accepts the user's OAuth token as the `Authorization` header — gives us a clean delegation path once ADK exposes user identity.
BigQuery (discovery, only when Dataplex is off) | **MCP `bigquery_list_*` / `bigquery_get_table_info`**          | When `DATAPLEX_ENABLED=false` the agent loses `dataplex_search` as a discovery path. The LLM still needs to find tables before handing them to CA (which requires explicit table references). The introspection tools cover exactly that gap. Execution stays on the CA path — see [`sources/bigquery.yaml`](sources/bigquery.yaml) for why `bigquery-execute-sql` is deliberately excluded.
Dataplex                                        | **Direct `dataplex_v1` SDK** (`dataplex_utils.py`)             | Preserves the `tool_context.auth` → user-creds-or-ADC pattern. When ADK populates `ToolContext.auth` with the end user's identity, every Dataplex call automatically executes as the user. MCP's Dataplex source doesn't support `useClientOAuth` upstream today, so routing through MCP would actively *prevent* per-user delegation.
GCS / future sources (Spanner, etc.)            | **This MCP Toolbox**                                           | No dedicated direct path. The manifest-driven extensibility (drop a YAML, redeploy) is exactly what's wanted for adding new auxiliary capabilities. Today these are SA-only at the data layer — acceptable for read-only browsing/exploration scenarios.

When MCP upstream adds `useClientOAuth` to more sources, or when Google's hosted
MCP servers (e.g.
[Dataplex Remote MCP](https://docs.cloud.google.com/dataplex/docs/use-remote-mcp))
reach GA and cover our needs, this division can be revisited.

## Day-1 sources

Source     | Tools                                                                                                               | Required env                                         | IAM granted to toolbox SA
---------- | ------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------- | -------------------------
`gcs`      | `gcs_list_buckets`, `gcs_list_objects`, `gcs_read_object`                                                           | `PROJECT_ID` (auto)                                  | `storage.objectViewer`
`bigquery` | `bigquery_list_datasets`, `bigquery_list_tables`, `bigquery_get_table_info` (introspection only — no SQL execution) | `PROJECT_ID` (auto)                                  | `bigquery.metadataViewer`
`spanner`  | *ships disabled* — see [Re-enabling Spanner](#re-enabling-spanner)                                                  | `PROJECT_ID`, `SPANNER_INSTANCE`, `SPANNER_DATABASE` | `spanner.databaseUser`, `spanner.viewer`

The toolbox service account always gets `roles/secretmanager.secretAccessor` for
the config secret.

### Choosing a manifest

Two manifests ship and the right one is **auto-selected from
`DATAPLEX_ENABLED`** — you don't normally pass `MANIFEST=` yourself.

Agent deploys with…               | Manifest auto-selected                                   | What it enables
--------------------------------- | -------------------------------------------------------- | ---------------
`DATAPLEX_ENABLED=true` (default) | [`manifest.yaml`](manifest.yaml)                         | GCS only — `dataplex_search` handles table discovery, so the BigQuery introspection source ships disabled.
`DATAPLEX_ENABLED=false`          | [`manifest-no-dataplex.yaml`](manifest-no-dataplex.yaml) | GCS + BigQuery introspection — the LLM uses `bigquery_list_*` / `bigquery_get_table_info` to find tables before handing them to `call_bigquery_ca`.

```bash
# Default (Dataplex on):
make deploy-all

# No-Dataplex variant — single flag flips both sides:
make deploy-all VARIANT=no-kc DATAPLEX_ENABLED=false
```

Pass an explicit `MANIFEST=path/to/custom.yaml` only when you need a non-default
combination (e.g. no-dataplex AND Spanner enabled). Explicit `MANIFEST=` wins
over the auto-selection.

## Deploy

Prerequisites: `gcloud auth application-default login` and `gcloud auth login`.

**First-time setup** (single command):

```bash
make deploy-all   # = make deploy-mcp + make deploy
```

This works because `deploy-mcp` can run before any agent exists: it predicts the
agent's runtime SA from the project number (Google's standard
`service-{N}@gcp-sa-aiplatform-re.iam.gserviceaccount.com`) and grants invoker
on it.

**Subsequent changes**: one command for whichever side changed.

```bash
make deploy-mcp   # tools.yaml or manifest changed
make deploy       # agent code changed (auto-picks MCP_TOOLBOX_URL from metadata)
```

What `make deploy-mcp` creates or updates: 1. APIs enabled: `run`,
`secretmanager`, `iam`, plus per-source APIs (`storage` today; `spanner` if
enabled). 2. Service account
`toolbox-identity@<project>.iam.gserviceaccount.com` with the IAM roles from
`manifest.yaml`. 3. Secret Manager secret `toolbox-tools-config` with a new
version containing the composed `tools.yaml`. 4. Cloud Run service
`data-agent-mcp-toolbox` (private, ID-token-only) running the official toolbox
image. 5. `roles/run.invoker` granted to the agent SA (predicted on first run;
read from `deployment_metadata.json` on subsequent runs). 6.
`deployment_metadata.json` updated with `mcp_toolbox_url` and
`mcp_toolbox_service_account`.

**Custom-SA edge case**: if you deploy the agent with `--agent-identity` or
`--service-account=<email>`, the predicted default SA is wrong. Re-run `make
deploy-mcp` once after `make deploy` — at that point `deployment_metadata.json`
has the real SA and the invoker grant moves to it.

Verify:

```bash
gcloud run services describe data-agent-mcp-toolbox --region us-central1 --format='value(status.url)'
URL=$(gcloud run services describe data-agent-mcp-toolbox --region us-central1 --format='value(status.url)')
curl -H "Authorization: Bearer $(gcloud auth print-identity-token)" "$URL/api/toolset"
```

The last command should return a JSON list of the loaded tools (3 GCS tools,
more if Spanner or other sources are enabled).

### One-time cleanup if you're upgrading from an earlier deploy

The deploy script grants IAM additively; it never removes stale bindings. If
your `toolbox-identity` SA still has roles from an earlier deploy that included
execution-capable BigQuery (`roles/bigquery.user`) or Dataplex
(`roles/dataplex.catalogViewer`), revoke them manually:

```bash
PROJECT=$(gcloud config get-value project)
SA="toolbox-identity@${PROJECT}.iam.gserviceaccount.com"
for role in roles/bigquery.user roles/dataplex.catalogViewer; do
  gcloud projects remove-iam-policy-binding "$PROJECT" \
    --member="serviceAccount:$SA" --role="$role" --quiet || true
done
```

(Note: `roles/bigquery.metadataViewer` is needed when the `bigquery` source is
enabled — don't remove it if you're using `manifest-no-dataplex.yaml`.)

Audit afterward:

```bash
gcloud projects get-iam-policy "$PROJECT" --flatten=bindings --filter="bindings.members:toolbox-identity*"
```

Should show `roles/secretmanager.secretAccessor` + `roles/storage.objectViewer`
(and `roles/bigquery.metadataViewer` if using the no-dataplex manifest, plus
Spanner roles if enabled).

## Add a new source

Three steps, no Python changes. Worked example: AlloyDB Postgres with IAM auth.

### Step 1 — drop a source fragment

Create [`sources/alloydb.yaml`](sources/) with the MCP source + tools + toolset:

```yaml
kind: source
name: alloydb-source
type: alloydb-postgres
project: ${PROJECT_ID}
cluster: ${ALLOYDB_CLUSTER}
instance: ${ALLOYDB_INSTANCE}
database: ${ALLOYDB_DATABASE}
user: ""  # empty = IAM auth via the toolbox SA
---
kind: tool
name: alloydb_execute_sql
type: alloydb-postgres-execute-sql
source: alloydb-source
description: Execute SQL against the AlloyDB database.
---
kind: toolset
name: alloydb
tools:
  - alloydb_execute_sql
```

### Step 2 — add a manifest entry

Append to [`manifest.yaml`](manifest.yaml):

```yaml
  alloydb:
    enabled: true
    file: sources/alloydb.yaml
    iam_roles:
      - roles/alloydb.client
      - roles/serviceusage.serviceUsageConsumer
    required_env: [PROJECT_ID, ALLOYDB_CLUSTER, ALLOYDB_INSTANCE, ALLOYDB_DATABASE]
    apis: [alloydb.googleapis.com]
    description: AlloyDB Postgres access (IAM-authenticated)
```

### Step 3 — deploy

```bash
make deploy-mcp EXTRA_ENV="ALLOYDB_CLUSTER=my-cluster,ALLOYDB_INSTANCE=my-inst,ALLOYDB_DATABASE=my-db"
```

The script picks up the new fragment from the manifest automatically: grants the
new IAM roles to `toolbox-identity`, includes the fragment in the composed
`tools.yaml`, pushes a new secret version, and redeploys. The agent picks up the
new tools on its next deploy or restart.

**Governance note**: most MCP sources are **SA-only** today (`useClientOAuth` is
implemented upstream only on the BigQuery source). If end-user IAM enforcement
is a requirement for the new source, evaluate carefully: see
[Access governance](#access-governance) below.

## Manifest schema reference

All fields except `enabled` and `file` are optional.

Field               | Type      | Default           | Purpose
------------------- | --------- | ----------------- | -------
`enabled`           | bool      | required          | When `false`, the source is excluded from `tools.yaml`, no IAM is granted, no env validation.
`file`              | str       | required          | Path (relative to `manifest.yaml`) to the per-source YAML fragment.
`iam_roles`         | list[str] | `[]`              | Project-level GCP roles granted to `toolbox-identity` when this source is enabled.
`required_env`      | list[str] | `[]`              | Env vars that must be set on Cloud Run. Deploy fails fast with a clear message if missing. `PROJECT_ID` is auto-set from the deploy project.
`required_secrets`  | list[str] | `[]`              | Env vars sourced from Secret Manager. Format: `"PG_PASSWORD=pg-pwd-secret:latest"`. Mapped to `gcloud --set-secrets`.
`apis`              | list[str] | `[]`              | GCP APIs to enable for this source.
`network.connector` | str       | `null`            | VPC connector for private-IP sources.
`network.egress`    | str       | `null`            | `all-traffic` or `private-ranges-only`.
`client_auth_mode`  | str       | `service_account` | One of `service_account`, `end_user`, `hybrid`. See [Access governance](#access-governance).
`description`       | str       | `""`              | Human-readable note.

## Re-enabling Spanner

The Spanner source ships pre-wired but disabled (no usable instance in this
project today). To turn it on:

1.  Edit [`manifest.yaml`](manifest.yaml): change `spanner.enabled: false` →
    `true`.
2.  Deploy with the instance/database supplied via env:

```bash
make deploy-mcp EXTRA_ENV="SPANNER_INSTANCE=your-inst,SPANNER_DATABASE=your-db"
```

The script will auto-grant `roles/spanner.databaseUser` and
`roles/spanner.viewer` to the toolbox SA and include the Spanner source in the
composed YAML. The agent picks up `spanner_execute_sql` and
`spanner_list_tables` on next deploy.

**Note**: like GCS, Spanner via MCP is SA-only today — Spanner's MCP source
doesn't yet implement `useClientOAuth`. If per-user IAM enforcement is required
on Spanner, consider direct SDK access (similar to the Dataplex path) until
upstream adds delegation support.

## Access governance

### Current reality

MCP Toolbox upstream supports the end-user delegation header (`useClientOAuth:
"X-Goog-User-Authorization"`) on the **BigQuery source only** today. GCS,
Spanner, Dataplex, and all other sources are SA-only — they always use the
toolbox SA's credentials regardless of what `client_auth_mode` is set to in the
manifest.

This project's MCP doesn't currently use any source that supports delegation, so
the `X-Goog-User-Authorization` header is forwarded but not honored anywhere.
The header plumbing stays in place because: 1. It costs nothing. 2. The moment
upstream MCP adds `useClientOAuth` to GCS/Spanner/etc., flipping
`client_auth_mode: end_user` in the manifest will activate delegation per-source
with zero additional code work.

### Two auth modes (when useClientOAuth is supported by the source)

When you eventually add a source that supports `useClientOAuth`:

-   **`service_account`** (default): the source uses the toolbox SA's GCP
    credentials. Data-system audit logs show `toolbox-identity@...` as the
    principal.
-   **`end_user`**: the toolbox forwards the end user's OAuth token (via
    `X-Goog-User-Authorization`) to the source, which uses it instead of the
    SA's. Data-system audit logs show the actual user.

### Hypothetical: switching a source to `end_user` mode

(Not currently applicable — none of our active sources upstream-support this
yet. Shown here so the recipe is documented for when it does.)

For a hypothetical BigQuery source added to the manifest:

1.  In `manifest.yaml`: `diff bigquery: enabled: true file:
    sources/bigquery.yaml + client_auth_mode: end_user`
2.  In `sources/bigquery.yaml`: `diff kind: source name: bigquery-source type:
    bigquery project: ${PROJECT_ID} - useClientOAuth: false + useClientOAuth:
    "X-Goog-User-Authorization" --- kind: tool name: bq_execute_sql type:
    bigquery-execute-sql source: bigquery-source + authRequired: [google-auth]`

Re-deploy with `make deploy-mcp`. The deploy script detects at least one source
has `client_auth_mode != service_account` and automatically prepends the Google
authService config from [`auth/google.yaml`](auth/google.yaml) to the composed
`tools.yaml`.

### OAuth scope requirements

When a source is in `end_user` mode, the end user's OAuth token must carry the
right scope. The agent's frontend (Gemini Enterprise) must request these scopes
at sign-in.

| Source              | Required OAuth scope                                   |
| ------------------- | ------------------------------------------------------ |
| BigQuery            | `https://www.googleapis.com/auth/bigquery`             |
: (hypothetical,      :                                                        :
: upstream-supported) :                                                        :
| GCS (read) — if     | `https://www.googleapis.com/auth/devstorage.read_only` |
: upstream adds       :                                                        :
: support             :                                                        :
| Spanner — if        | `https://www.googleapis.com/auth/spanner.data`         |
: upstream adds       :                                                        :
: support             :                                                        :

### Wire-up status (read this before flipping `end_user`)

The agent calls the toolbox today and forwards a Google ID token
(`Authorization` header) — `service_account` mode works end-to-end. The
`X-Goog-User-Authorization` header is wired through a callable in
[`app/ca_toolbox_engine_app.py`](../ca_toolbox_engine_app.py) that delegates to
[`app/auth_utils.py:get_end_user_token()`](../auth_utils.py), which returns
`None` today because ADK's `ToolContext` doesn't expose the end user's identity
(framework gap, not a coding gap).

When ADK / Vertex AI Agent Engine adds a way to read the caller's OAuth token at
tool-call time, populate `get_end_user_token()` — that one-line change activates
`end_user` mode for every source that *also* upstream-supports `useClientOAuth`.

**Until then**: `client_auth_mode: end_user` is config-complete but
doubly-inert: (1) the hook returns None so no user token is forwarded, and (2)
no current source honors the header even if it were. Stick to `service_account`
for production use.

### Verifying the hook in isolation

To test that your manifest changes work end-to-end before the upstream pieces
land, set a fake user token on the agent (and add a hypothetical BQ source to
confirm the header arrives):

```bash
make deploy AGENT_IDENTITY=true   # add: --set-env-vars _FAKE_USER_TOKEN_FOR_TESTING=test123
```

Then watch the toolbox logs (`gcloud run services logs read
data-agent-mcp-toolbox`) — incoming requests should carry
`X-Goog-User-Authorization: Bearer test123`. (Whether the source DOES anything
with it depends on upstream `useClientOAuth` support.)

### Limitations

-   **Most sources are SA-only upstream today**. Only BigQuery has
    `useClientOAuth` implemented in MCP Toolbox; GCS, Spanner, Dataplex, and
    others always use the toolbox SA.
-   **Password-auth sources** (Cloud SQL with password, Mongo with password,
    etc.) cannot do per-user — the credential is a single shared secret. Leave
    `client_auth_mode: service_account` on these.
-   **Cross-org users**: end-user delegation only works for users in the same
    Google Cloud organization that owns the data resources.

### Where governance actually lives in this project

For the data systems we *do* have governed requirements on (BigQuery SQL
execution and Dataplex), governance is handled by the **direct paths**
(`ca_toolbox_agent.py` and `dataplex_utils.py`), not MCP. Those paths read
`tool_context.auth` via `auth_utils.get_user_credentials()` — falling back to
ADC today, but ready to use the end user's credentials the moment ADK populates
that field.

The BigQuery introspection tools we *do* expose via MCP (in the no-dataplex
variant) inherit the toolbox's SA-only auth today. Upstream MCP supports
`useClientOAuth` on the BigQuery source, so flipping `client_auth_mode:
end_user` in `manifest-no-dataplex.yaml` will activate delegation for those
introspection calls the moment `get_end_user_token()` returns a real token. See
the project root [README.md](../../README.md) for the architectural overview.

## Operations

Common operator tasks:

**Get the service URL** `bash gcloud run services describe
data-agent-mcp-toolbox --region us-central1 --format='value(status.url)'`

**View toolbox logs** `bash gcloud run services logs read data-agent-mcp-toolbox
--region us-central1`

**Update the config (edit a source's YAML or the manifest)** `bash make
deploy-mcp` This creates a new Secret Manager version and a new Cloud Run
revision.

**Audit IAM on the toolbox SA** `bash gcloud projects get-iam-policy <PROJECT>
--flatten=bindings --filter="bindings.members:toolbox-identity*"`

**Force a clean redeploy** `bash gcloud run services delete
data-agent-mcp-toolbox --region us-central1 make deploy-mcp`

**Smoke-test a tool from your laptop** `bash URL=$(gcloud run services describe
data-agent-mcp-toolbox --region us-central1 --format='value(status.url)') curl
-H "Authorization: Bearer $(gcloud auth print-identity-token)"
"$URL/api/toolset" curl -H "Authorization: Bearer $(gcloud auth
print-identity-token)" \ -H "Content-Type: application/json" \ -d '{}' \
"$URL/api/tool/gcs_list_buckets/invoke"`

## Troubleshooting

Symptom                                                                         | Diagnosis
------------------------------------------------------------------------------- | ---------
`PERMISSION_DENIED` from GCS                                                    | Toolbox SA missing `roles/storage.objectViewer`. Check `gcloud projects get-iam-policy`.
Agent gets `403` calling the toolbox                                            | Agent SA missing `roles/run.invoker` on the toolbox service. Usually means `make deploy-mcp` ran before the agent SA was known. Fix: re-run `make deploy-mcp` after `make deploy` to grant on the actual SA from `deployment_metadata.json`.
Deploy script: `Secret not found`                                               | First-time deploy on a new project; re-run `make deploy-mcp` (the secret is created on the first run, but a race with API enablement can fail).
`unknown source kind: X` in Cloud Run logs                                      | The MCP image is older than your source type. Bump `--image` to a newer tag.
`Missing required env vars: SPANNER_INSTANCE, ...`                              | A source's `required_env` weren't passed. Add via `make deploy-mcp EXTRA_ENV="SPANNER_INSTANCE=foo,..."`.
`Source fragment not found: sources/X.yaml`                                     | Manifest references a file that doesn't exist. Either drop the fragment in `sources/` or remove the manifest entry.
Cloud Run revision stuck `not ready`                                            | `gcloud run services logs read data-agent-mcp-toolbox --region us-central1` — usually a YAML parse error or invalid env-var reference.
Agent loads no tools (only stubs)                                               | Check `MCP_TOOLBOX_URL` is set on the Agent Engine (look at the deploy log; should print `Found MCP Toolbox URL: ...`). If not, `deployment_metadata.json` is missing `mcp_toolbox_url` — re-run `make deploy-mcp`.
Toolbox SA still has BQ / Dataplex roles after upgrading from an earlier deploy | See the [One-time cleanup](#one-time-cleanup-if-youre-upgrading-from-an-earlier-deploy-that-included-bigquery--dataplex) section.

## Architecture deep-dive

```
make deploy-mcp
   │
   ├─► load manifest.yaml
   ├─► validate enabled sources (env, fragments exist, mode)
   ├─► compose tools.yaml (concat fragments + auth/google.yaml if any end_user)
   ├─► enable APIs (gcloud services enable)
   ├─► create-or-get toolbox-identity SA (gcloud iam service-accounts)
   ├─► grant project IAM (resourcemanager_v3 - idempotent per role+member)
   ├─► upsert Secret Manager secret (gcloud secrets create/versions add)
   ├─► deploy Cloud Run service (gcloud run deploy)
   ├─► grant agent SA roles/run.invoker (gcloud run services add-iam-policy-binding)
   └─► merge mcp_toolbox_url into deployment_metadata.json
```

Why this shape:

-   **Prebuilt image**
    (`us-central1-docker.pkg.dev/database-toolbox/toolbox/toolbox:latest`): no
    Dockerfile to maintain; upstream image tracks new sources automatically.
-   **Per-source fragments**: extensibility primary. Adding a source touches two
    files (fragment + manifest entry), zero Python.
-   **`gcloud` via subprocess** for Cloud Run / Secret Manager / project IAM:
    matches MCP toolbox docs verbatim, no new Python deps. (Agent Engine deploy
    at [app/app_utils/deploy.py](../app_utils/deploy.py) keeps using the
    vertexai SDK because `AgentEngineConfig` is complex; Cloud Run isn't.)
-   **`deployment_metadata.json` as handoff**: loose coupling between agent and
    toolbox deploys. Either can be re-run independently.
-   **MCP is intentionally scoped**: GCS (always) + BigQuery introspection (only
    when Dataplex is disabled). See
    [Why this project's MCP is scoped this way](#why-this-projects-mcp-is-scoped-this-way).

## Future work

Known gaps deliberately deferred:

-   **Upstream MCP `useClientOAuth` on GCS / Spanner / Dataplex**: file an issue
    at https://github.com/googleapis/genai-toolbox/ requesting this. When
    merged, our sources can flip to `end_user` mode with no code change.
-   **Populating `get_end_user_token()`** — depends on ADK / Agent Engine
    exposing the end user's OAuth token in `ToolContext`. Hook is in place at
    [`../auth_utils.py`](../auth_utils.py); when upstream lands this is a
    one-function change.
-   **Revisit Google's hosted
    [Dataplex Remote MCP](https://docs.cloud.google.com/dataplex/docs/use-remote-mcp)**
    when it reaches GA — it has native OAuth + IAM delegation and could replace
    the direct `dataplex_v1` SDK path entirely.
-   **File-based credentials** (TLS certs as mounted files for Neo4j mTLS, etc.)
    — add a `required_files:` field to the manifest schema when first needed.
-   **Per-environment manifests** (dev / staging / prod) — currently one
    manifest, deployed against the active gcloud project.
