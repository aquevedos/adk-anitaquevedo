# Knowledge Catalog Integrated Analytics Agent — User & Developer Guide

This guide explains how to design, build, and deploy an enterprise-grade Data Analytics Agent integrated with the **Dataplex Knowledge Catalog** on Google Cloud. Based on the architecture of the `data-agent-kc-toolbox`, this document details the core concepts, orchestration patterns, and concrete code implementations required to build a catalog-driven AI agent.

---

## 1. Architectural Overview & Core Concepts

Traditional data agents rely on static tool definitions and direct table querying, requiring the LLM to possess prior understanding of where data lives and what business rules apply. 

A **Catalog-Driven Analytics Agent** inverts this model: it uses the Dataplex Knowledge Catalog as a semantic control plane. Before executing any query, the agent discovers both the physical data assets (tables, filesets, databases) and the semantic governance metadata (glossaries, business terms, data policies) needed to ground the user's request.

```mermaid
flowchart TD
    Q[User Question] --> S[Stage 1: Catalog Search<br>dataplex_search]
    
    subgraph Knowledge Catalog
        S -->|Keyword & Semantic| R1[BIGQUERY Tables/Views]
        S -->|System & Asset| R2[CLOUD_STORAGE / SPANNER]
        S -->|Unscoped Catch-all| R3[KNOWLEDGE Policies & Terms]
    end
    
    R1 --> F[Stage 2: Fetch Deep Context<br>get_entries_context]
    R2 --> F
    R3 --> F
    
    F --> D[Stage 3: LLM Decision & Routing]
    
    D -->|Category: BIGQUERY| CA[Stage 4: BigQuery Conversational Analytics<br>call_bigquery_ca]
    D -->|Category: CLOUD_STORAGE / SPANNER| MCP[MCP Toolbox Sidecar<br>gcs_* / spanner_*]
    D -->|Category: KNOWLEDGE| DIRECT[Direct Definitional Answer]
    D -->|Missing Context| REFINE[Refine & Re-search<br>Max 3 Rounds]
    
    subgraph Execution & Grounding
        CA -->|NL to SQL + Inlined Rules| BQ[(BigQuery Engine)]
        MCP -->|Direct Tool Invocation| EXT[(External Data / GCS)]
    end
```

### Key Concepts

#### 1. Catalog-Driven Routing (`Category:` Tagging)
Every entry discovered in Dataplex is classified into a target execution system (`BIGQUERY`, `CLOUD_STORAGE`, `SPANNER`, `DATAPLEX`, `KNOWLEDGE`). Instead of the agent assuming every question is a SQL query, the orchestration prompt uses these `Category:` tags to route entries to the appropriate execution mechanism or handler.

#### 2. The 3-Stage Core Workflow
To ensure predictable and verifiable execution, the orchestration agent strictly follows a three-stage loop:
1. **Search (`dataplex_search`)**: Discovers candidate entries across multiple facets (semantic, keyword, and cross-project knowledge).
2. **Fetch Context (`get_entries_context`)**: Retrieves deep metadata (aspects, `LookupContext`, and inlined GCS policy text) for a curated subset of relevant entries.
3. **Decide & Execute**: Evaluates the fetched context to either execute a query, call an MCP tool, answer directly from policy text, or refine the search (up to a hard budget of 3 rounds).

#### 3. Per-System Handler Pattern
Systems requiring complex, multi-step orchestration—such as BigQuery Conversational Analytics (CA) which manages NL-to-SQL generation, execution, and insight generation—are wrapped in dedicated Python tool functions (e.g., [call_bigquery_ca](file:///google/src/cloud/lluiscanet/kc-tooling/google3/prototypes/projects/knowledge-catalog-enrichment/datacloud-ai-innovation/data-agent-kc-toolbox/app/ca_toolbox_agent.py#L321)). Simpler systems (like Cloud Storage or Spanner) are exposed directly as Model Context Protocol (MCP) tools that the LLM dispatches directly from the prompt.

#### 4. Grounding Transcription (Inlining)
Execution engines like BigQuery Conversational Analytics do not have direct access to the Knowledge Catalog. To ensure SQL queries adhere to enterprise governance, the orchestration agent extracts concrete business rules, calculation formulas, and SQL filter predicates from `KNOWLEDGE` entries and transcribes them directly into the `inline_instruction` payload sent to the execution engine.

---

## 2. Step-by-Step Implementation Guide

The following sections provide the concrete implementation details and example code for building each layer of the agent using the **Google Agent Development Kit (ADK)** and the **Google GenAI SDK**.

### Step 1: Initializing the Model and Framework (ADK)

When deploying agents to Vertex AI Agent Engine, preview models (e.g., `gemini-3-flash-preview`) are typically hosted on the `global` publisher endpoint, whereas the Reasoning Engine runtime operates regionally (e.g., `us-central1`). 

To prevent regional 404 model lookup errors while keeping the Reasoning Engine session service correctly pointed at its regional deployment, we define a custom `GlobalGemini` class that pins the underlying GenAI client to `location="global"`.

```python
# app/ca_toolbox_kc_wrapper.py
from functools import cached_property
import os
from google.adk.agents.llm_agent import LlmAgent as Agent
from google.adk.apps.app import App
from google.adk.models import Gemini
from google.genai import Client, types

class GlobalGemini(Gemini):
  """Gemini model pinned to the `global` Vertex AI publisher endpoint."""
  @cached_property
  def api_client(self) -> Client:
    # Forces model lookups to the global publisher registry without altering
    # GOOGLE_CLOUD_LOCATION, which Vertex AI Reasoning Engine relies on.
    return Client(vertexai=True, location="global")

# Tell GenAI SDK to use Vertex AI backend
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"

model = GlobalGemini(
    model="gemini-3-flash-preview",
    retry_options=types.HttpRetryOptions(attempts=3),
)
```

---

### Step 2: Implementing Catalog Search (`dataplex_search`)

The search tool acts as the agent's eyes. It executes multiple targeted queries against the Dataplex Catalog and merges the results with deduplication. It also includes stateful budget tracking to enforce a hard stop after 3 search rounds, preventing runaway LLM loops.

```python
# app/dataplex_utils.py
import logging
from typing import Any
from google.adk.tools.tool_context import ToolContext
from google.cloud import dataplex_v1
from . import auth_utils

PROJECT_ID = auth_utils.resolve_project_id()
PROJECT_NAME = os.environ.get("DATAPLEX_CATALOG_PROJECT", PROJECT_ID)
MAX_SEARCHES = 3

def _classify_entry_system(entry: Any) -> str:
  """Classify Dataplex entry into a routing system tag."""
  et = (getattr(entry, "entry_type", "") or "").lower()
  name = (getattr(entry, "name", "") or "").lower()
  if "bigquery" in et:
    return "BIGQUERY"
  if any(k in et for k in ("cloud_storage", "gcs", "fileset", "bucket")) or "gs://" in name:
    return "CLOUD_STORAGE"
  if "spanner" in et or "spanner" in name:
    return "SPANNER"
  if "dataplex" in et:
    return "DATAPLEX"
  return "KNOWLEDGE"

def dataplex_search(query: str, tool_context: ToolContext) -> str:
  """Searches Dataplex Catalog across semantic, keyword, and knowledge facets."""
  # Stateful budget tracking per conversation turn
  invocation_id = getattr(tool_context, "invocation_id", "default") or "default"
  state_key = f"dataplex_search_count:{invocation_id}"
  state = getattr(tool_context, "state", None)
  
  if state is not None:
    count = state.get(state_key, 0)
    if count >= MAX_SEARCHES:
      return (
          f"SEARCH LIMIT REACHED ({count}/{MAX_SEARCHES}). STOP searching. "
          "Decide based on the entries you have already fetched via get_entries_context. "
          "Pick action (A) call_bigquery_ca, (B) direct definitional answer, or (C) MCP tool call."
      )
    state[state_key] = count + 1

  creds = auth_utils.get_user_credentials(tool_context)
  client = dataplex_v1.CatalogServiceClient(credentials=creds)
  location_name = f"projects/{PROJECT_ID}/locations/global"

  # 1. Semantic search scoped to data project
  semantic_query = f"{query} projectid:({PROJECT_NAME})"
  sem_req = dataplex_v1.SearchEntriesRequest(
      name=location_name, query=semantic_query, page_size=15, semantic_search=True
  )
  semantic_results = list(client.search_entries(request=sem_req).results)

  # 2. Keyword search for BigQuery tables/views
  bq_query = f"system=BIGQUERY (type=TABLE OR type=VIEW) projectid:({PROJECT_NAME})"
  bq_req = dataplex_v1.SearchEntriesRequest(
      name=location_name, query=bq_query, page_size=15, semantic_search=False
  )
  bq_results = list(client.search_entries(request=bq_req).results)

  # 3. Unscoped Knowledge catch-all (surfaces cross-project glossaries/policies)
  know_req = dataplex_v1.SearchEntriesRequest(
      name=location_name, query=query, page_size=15, semantic_search=True
  )
  knowledge_results = list(client.search_entries(request=know_req).results)

  # Merge and deduplicate results
  entry_names = []
  systems = {}
  seen = set()

  for items in (semantic_results, bq_results, knowledge_results):
    for item in items:
      name = getattr(item.dataplex_entry, "name", "Unknown")
      if name in seen or name == "Unknown":
        continue
      seen.add(name)
      entry_names.append(name)
      systems[name] = _classify_entry_system(item.dataplex_entry)

  # Format brief summary for the LLM
  lines = []
  for name in entry_names:
    sys_tag = systems[name]
    lines.append(f"Entry Name: {name}\nCategory: {sys_tag}\n---")
  
  return "\n".join(lines) if lines else "No entries found."
```

---

### Step 3: Implementing Deep Context Retrieval (`get_entries_context`)

Once the LLM selects the relevant entry names from the search results, `get_entries_context` retrieves the complete metadata payload. Crucially, if an entry's source points to a Cloud Storage file (`gs://`), this utility downloads and inlines the document's text into the payload.

```python
# app/dataplex_utils.py
import json
import google.protobuf.json_format as jsonpb

GCS_MAX_BYTES = 16 * 1024  # 16KB truncation cap for policy documents

def _fetch_gcs_text(gs_uri: str) -> str:
  """Downloads and truncates text from a GCS URI."""
  try:
    from google.cloud import storage
    if not gs_uri.startswith("gs://"):
      return ""
    path = gs_uri[len("gs://"):]
    bucket_name, _, object_name = path.partition("/")
    client = storage.Client()
    blob = client.bucket(bucket_name).blob(object_name)
    data = blob.download_as_bytes(start=0, end=GCS_MAX_BYTES - 1)
    text = data.decode("utf-8", errors="replace")
    if len(data) >= GCS_MAX_BYTES:
      text += f"\n\n[... truncated at {GCS_MAX_BYTES} bytes ...]"
    return text
  except Exception as e:
    logging.warning(f"Could not fetch GCS object {gs_uri}: {e}")
    return ""

def get_entries_context(entry_names: list[str], tool_context: ToolContext) -> str:
  """Fetches full aspects, LookupContext, and inlined GCS text for selected entries."""
  creds = auth_utils.get_user_credentials(tool_context)
  client = dataplex_v1.CatalogServiceClient(credentials=creds)
  state = getattr(tool_context, "state", {})
  results = []

  for name in entry_names:
    # 1. Fetch Full Entry Info
    req = dataplex_v1.GetEntryRequest(name=name, view="FULL")
    entry = client.get_entry(request=req)
    entry_dict = jsonpb.MessageToDict(entry._pb)
    
    # Extract description or GCS backing document
    overview = entry_dict.get("description", "")
    source_dict = entry_dict.get("entrySource", {})
    
    # Check for gs:// link in source metadata
    gcs_uri = None
    for val in source_dict.values():
      if isinstance(val, str) and "gs://" in val:
        gcs_uri = val[val.find("gs://"):].split()[0]
        break
    
    if gcs_uri:
      gcs_text = _fetch_gcs_text(gcs_uri)
      overview = f"{overview}\n\n--- Content of {gcs_uri} ---\n{gcs_text}"

    # 2. Fetch LookupContext (Lineage & Relationships)
    ctx_str = ""
    try:
      parts = name.split("/")
      loc = parts[parts.index("locations") + 1] if "locations" in parts else "global"
      lookup_req = dataplex_v1.LookupContextRequest(
          name=f"projects/{PROJECT_ID}/locations/{loc}",
          resources=[name],
          options={"format": "yaml", "allowed_entries": json.dumps([name])}
      )
      res = client.lookup_context(request=lookup_req)
      ctx_str = getattr(res, "context", "")
    except Exception:
      pass

    # Combine into a rich structured representation
    entry_dump = (
        f"Entry Name: {name}\nDescription:\n{overview}\n"
        f"--- Aspects ---\n{json.dumps(entry_dict.get('aspects', {}), indent=2)}\n"
        f"--- LookupContext ---\n{ctx_str}\n==="
    )
    results.append(entry_dump)

  return "\n".join(results) if results else "No context found."
```

---

### Step 4: Designing the Orchestration Prompt

The system prompt must establish strict behavioral boundaries for the LLM, enforcing the search-fetch-execute loop and detailing how to transcribe grounding rules into downstream tool calls.

```python
# app/ca_toolbox_kc_wrapper.py
INSTRUCTION_WITH_DATAPLEX = """# Role & Objectives
You are an intelligent Data Analytics and Metadata Orchestration Agent. Your goal is to use the Knowledge Catalog to execute the right BigQuery Conversational Analytics call **efficiently and correctly**. The catalog's non-BigQuery entries (policies, glossaries, business terms) are **grounding** that tells you which BigQuery tables to use, how to filter them, and which business definitions matter.

## Tool Set (FIXED — never invent tools)
Your primary tools are: `dataplex_search`, `get_entries_context`, `call_bigquery_ca`. Dynamic MCP tools (`gcs_*`, `spanner_*`) are also available.

## Core Workflow
For every user question, work in three stages: **search → fetch context → execute**.

### Stage 1 — Search
Call `dataplex_search` to discover relevant entries in the Knowledge Catalog. Read each entry's name, System tag, and brief description. Pick ONLY the entries that genuinely look related to the question (typically 3-10).

### Stage 2 — Fetch Context (MANDATORY)
After every `dataplex_search`, your next tool call MUST be `get_entries_context` with the specific entry names you selected in Stage 1. Never call `dataplex_search` twice in a row.

### Stage 3 — Decide & Execute
Read the fetched context and pick the matching path:
1. **Analytical Question (BigQuery)**: You found relevant BQ tables and enough context. Call `call_bigquery_ca`.
2. **Cloud Storage / Spanner**: You found entries tagged `CLOUD_STORAGE` or `SPANNER`. Call the corresponding MCP tools directly.
3. **Definitional / Policy Question**: The question asks about a policy or business concept. Answer directly from the fetched entry content; DO NOT call `call_bigquery_ca`. Cite the catalog entry.
4. **Refine Search**: If information is missing, call `dataplex_search` again with a refined query. (Hard cap: at most 3 search rounds).

### Stage 4 — Execute via BigQuery Conversational Analytics
When calling `call_bigquery_ca`, provide:
- `entry_names`: The BigQuery table names to query, plus any KNOWLEDGE entries used for grounding.
- `question`: The user's verbatim question.
- `inline_instruction`: **CRITICAL:** You must transcribe concrete grounding from KNOWLEDGE entries here. Do not refer to entries by name; paste the actual rules, formulas, or SQL predicates verbatim.

  - ❌ **Wrong**: "Use the Premium customer definition from customer-policy." (CA cannot look this up).
  - ✅ **Right**: "Apply the Premium customer definition: `users.traffic_source IN ('Email', 'Search') AND orders >= 3` (source: customer-policy). Then calculate AOV."

## Output & Explanations
- Describe what the catalog surfaced.
- Describe what BigQuery did and return its outputs directly (SQL, tables, insights).
"""
```

---

### Step 5: Creating the Per-System Execution Wrapper (`call_bigquery_ca`)

The execution wrapper bridges the ADK orchestration agent and the BigQuery Conversational Analytics API. It performs **defensive grounding injection**—extracting policy descriptions and prepending them directly to the prompt to guarantee governance adherence even if the LLM's transcription was imperfect.

```python
# app/ca_toolbox_agent.py
import logging
import re
import uuid
from typing import Any
from google.adk.tools.tool_context import ToolContext
from google.api_core import client_options
from google.cloud import geminidataanalytics_v1beta as geminidataanalytics
from . import auth_utils

def call_bigquery_ca(
    entry_names: list[str],
    question: str,
    inline_instruction: str,
    tool_context: ToolContext,
) -> str:
  """Per-system handler for BigQuery entries invoking Conversational Analytics."""
  creds = auth_utils.get_user_credentials(tool_context)
  project_id = auth_utils.resolve_project_id()

  if not entry_names:
    return "Error: Cannot call BigQuery CA with no table references. Discover tables."

  # 1. Parse BQ Table References & Separate Knowledge Entries
  table_references = []
  non_bq_entries = []
  
  for name in entry_names:
    match = re.search(r"projects/([^/]+)/datasets/([^/]+)/tables/([^/]+)", name)
    if match:
      proj, dset, tbl = match.groups()
      table_references.append({"project_id": proj, "dataset_id": dset, "table_id": tbl})
    elif "entryGroups" in name:
      non_bq_entries.append(name)

  if not table_references:
    return "Error: No valid BigQuery table references provided."

  # 2. Defensive Grounding Injection
  # Prepend actual catalog descriptions directly into the instruction payload
  # to ensure absolute governance compliance by the downstream SQL engine.
  if non_bq_entries:
    from google.cloud import dataplex_v1
    from .dataplex_utils import get_entry_overview
    dp_client = dataplex_v1.CatalogServiceClient(credentials=creds)
    grounding_parts = []
    for name in non_bq_entries:
      overview = get_entry_overview(name, dp_client, tool_context)
      if overview and overview != "No description available.":
        short_name = name.split("/entries/")[-1]
        grounding_parts.append(f"=== Grounding from `{short_name}` ===\n{overview}")
    
    if grounding_parts:
      grounding_block = "\n\n".join(grounding_parts)
      inline_instruction = (
          "GROUNDING RULES (apply these definitions, filters, and business "
          "logic verbatim when generating SQL — do NOT ignore them):\n\n"
          f"{grounding_block}\n\n---\n\nUSER INSTRUCTION:\n{inline_instruction}"
      )

  # 3. Invoke Conversational Analytics API
  opts = client_options.ClientOptions(api_endpoint="geminidataanalytics.googleapis.com")
  agent_client = geminidataanalytics.DataAgentServiceClient(credentials=creds, client_options=opts)
  chat_client = geminidataanalytics.DataChatServiceClient(credentials=creds, client_options=opts)
  parent = f"projects/{project_id}/locations/global"
  agent_id = f"tool-agent-{uuid.uuid4().hex[:8]}"

  inline_ctx = {"system_instruction": f"Instructions: {inline_instruction}"}
  if table_references:
    inline_ctx["datasource_references"] = {"bq": {"table_references": table_references}}

  # Create Ephemeral Data Agent
  data_agent = geminidataanalytics.DataAgent(
      display_name="CA Toolbox Agent",
      data_analytics_agent={"published_context": inline_ctx},
  )
  create_req = geminidataanalytics.CreateDataAgentRequest(
      parent=parent, data_agent_id=agent_id, data_agent=data_agent
  )
  
  try:
    agent_resp = agent_client.create_data_agent(request=create_req).result()
    agent_name = agent_resp.name
  except Exception:
    agent_name = f"{parent}/dataAgents/{agent_id}"

  # Create Conversation & Send Message
  conv_req = geminidataanalytics.CreateConversationRequest(
      parent=parent,
      conversation=geminidataanalytics.Conversation(agents=[agent_name], labels={"host": "bigquery"}),
  )
  conv_name = chat_client.create_conversation(request=conv_req).name

  chat_req = geminidataanalytics.ChatRequest(
      parent=parent,
      conversation_reference=geminidataanalytics.ConversationReference(
          conversation=conv_name,
          data_agent_context=geminidataanalytics.DataAgentContext(data_agent=agent_name),
      ),
      messages=[geminidataanalytics.Message(user_message=geminidataanalytics.UserMessage(text=question))],
      thinking_mode=geminidataanalytics.ChatRequest.ThinkingMode.THINKING,
  )

  responses = chat_client.chat(request=chat_req)

  # 4. Parse Streamed Responses (SQL, Tables, Text)
  final_answer = ""
  sqls = []
  tables = []

  for chunk in responses:
    sys_msg = chunk.system_message
    if not sys_msg:
      continue
    if sys_msg.text and sys_msg.text.parts:
      final_answer += "".join(sys_msg.text.parts)
    if sys_msg.data:
      if sys_msg.data.generated_sql:
        sqls.append(sys_msg.data.generated_sql)
      if sys_msg.data.result:
        # Format tabular markdown...
        pass # (Omitted for brevity; see ca_toolbox_agent.py for full table formatter)

  # Append deep link to BigQuery Agents Hub UI
  agent_uuid = agent_name.split("/")[-1]
  chat_uuid = conv_name.split("/")[-1]
  link_url = f"https://console.cloud.google.com/bigquery/agents_hub;agentsHubTab=Conversations;agentsPath=%2Fbq%2Fagents%2F{agent_uuid};chatPath=%2Fbq%2Fchat%2F{chat_uuid}?project={project_id}"
  
  final_answer += f"\n\n### Conversation Link\nView this session in the [BigQuery Agents Hub]({link_url})."
  return final_answer
```

---

### Step 6: Wires and Deployment (`ca_toolbox_engine_app.py`)

To deploy the agent to Vertex AI Agent Engine, we create an entrypoint that loads MCP Toolbox sidecar tools at startup and patches the Reasoning Engine session service to support seamless auto-creation of user sessions.

```python
# app/ca_toolbox_engine_app.py
import logging
import os
from typing import Any
import vertexai
from vertexai.agent_engines.templates.adk import AdkApp
from google.adk.tools.function_tool import FunctionTool
from app.auth_utils import get_end_user_token, is_local_mcp_url, resolve_project_id
from app.ca_toolbox_kc_wrapper import app as adk_app, orchestration_agent

def _load_mcp_toolbox_tools(url: str) -> list[Any]:
  """Connect to deployed MCP Toolbox sidecar and return ADK FunctionTools."""
  # ToolboxSyncClient maintains a background thread/loop to prevent aiohttp
  # session timeouts across Vertex AI's multi-loop request lifecycle.
  from toolbox_core import ToolboxSyncClient, auth_methods
  client_headers = {}

  if not is_local_mcp_url(url):
    # Attach Google ID Token for Cloud Run IAM authentication
    client_headers["Authorization"] = auth_methods.aget_google_id_token(url)

  user_token = get_end_user_token()
  if user_token:
    # Attach End-User OAuth token for user-delegated data access
    client_headers["X-Goog-User-Authorization"] = f"Bearer {user_token}"

  client = ToolboxSyncClient(url, client_headers=client_headers)
  return [FunctionTool(func=t) for t in client.load_toolset()]

def _attach_mcp_tools() -> None:
  """Dynamically load MCP tools and attach them to the root agent."""
  if getattr(orchestration_agent, "_mcp_tools_attached", False):
    return
  orchestration_agent._mcp_tools_attached = True
  url = os.environ.get("MCP_TOOLBOX_URL")
  if url:
    try:
      tools = _load_mcp_toolbox_tools(url)
      orchestration_agent.tools.extend(tools)
      logging.info(f"Successfully loaded {len(tools)} MCP tools from {url}")
    except Exception as e:
      logging.warning(f"Failed to load MCP tools: {e}. Running with stub tools.")

def _wrap_session_service_for_auto_create(session_service: Any) -> None:
  """Patch create_session to ignore stale client-minted session IDs."""
  if session_service is None:
    return
  original = session_service.create_session
  async def _create_session_ignore_id(*, app_name: str, user_id: str, session_id: Any = None, **kwargs: Any) -> Any:
    # Vertex AI Reasoning Engine rejects client-minted session IDs. Dropping
    # the kwarg forces the server to mint a fresh, valid session ID.
    return await original(app_name=app_name, user_id=user_id, **kwargs)
  session_service.create_session = _create_session_ignore_id

class AgentEngineApp(AdkApp):
  def set_up(self) -> None:
    project_id = resolve_project_id()
    vertexai.init(project=project_id)
    _attach_mcp_tools()
    super().set_up()
    
    # Enable auto-creation of missing sessions
    runner = self._tmpl_attrs.get("runner")
    if runner is not None:
      runner.auto_create_session = True
      _wrap_session_service_for_auto_create(runner.session_service)

agent_engine = AgentEngineApp(app=adk_app)
```

---

## 3. Verification & Lifecycle Management

### Local Development & Testing
You can test the entire orchestration flow locally on your machine without deploying to Cloud Run or Vertex AI:
```bash
# Terminal 1: Start the MCP Toolbox sidecar locally (port 5001)
make local-mcp

# Terminal 2: Launch the interactive agent playground pointed at the local sidecar
MCP_TOOLBOX_URL=http://localhost:5001 make playground
```

### Production Deployment
Deploy both the MCP Toolbox Cloud Run sidecar and the Vertex AI Agent Engine application in a single command:
```bash
export GOOGLE_CLOUD_PROJECT="<your-project-id>"
gcloud config set project "$GOOGLE_CLOUD_PROJECT"

# Deploys sidecar, configures IAM bindings, and deploys Agent Engine app
make deploy-all
```

### Managing Variants
To deploy multiple coexisting configurations (e.g., one with Dataplex enabled and one without), use the `VARIANT` parameter:
```bash
# Deploy a variant with Dataplex disabled (uses bigquery introspection MCP tools)
make deploy-all VARIANT=no-kc DATAPLEX_ENABLED=false
```
